<?php
/**
 * Plugin Name:  KNX Menu Studio
 * Description:  Shortcode [knx_menu_studio] — modular workspace for menu data
 *               tools. Screens: home (chooser), capture, harvest (placeholder).
 *               Requires KNX session with admin role. Redirects to / otherwise.
 * Version:      1.0.0
 * Author:       Our Local Collective
 * Text Domain:  knx-menu-studio
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'KNX_STUDIO_VERSION', '1.0.0' );
define( 'KNX_STUDIO_DIR',     plugin_dir_path( __FILE__ ) );
define( 'KNX_STUDIO_URL',     plugin_dir_url( __FILE__ ) );

/* Auto-versioning: uses file mtime so cache busts on every upload */
function knx_studio_asset_ver( $relative_path ) {
    $abs = KNX_STUDIO_DIR . $relative_path;
    return file_exists( $abs ) ? filemtime( $abs ) : KNX_STUDIO_VERSION;
}

/* ──────────────────────────────────────────────────────────────
   Allowed roles — every KNX role EXCEPT customer and driver.
   ────────────────────────────────────────────────────────────── */
define( 'KNX_STUDIO_ALLOWED_ROLES', [
    'super_admin',
    'manager',
    'hub_management',
    'menu_uploader',
] );

/* ══════════════════════════════════════════════════════════════
   1. SHORTCODE  [knx_menu_studio]
      Attributes:
        screen  = "home" (default) | "capture" | "harvest"

      Recommended page setup:
        /menu-studio/           → [knx_menu_studio]
        /menu-studio/capture/   → [knx_menu_studio screen="capture"]
        /menu-studio/harvest/   → [knx_menu_studio screen="harvest"]
   ══════════════════════════════════════════════════════════════ */
add_shortcode( 'knx_menu_studio', 'knx_menu_studio_shortcode' );

function knx_menu_studio_shortcode( $atts ) {

    $atts = shortcode_atts( [
        'screen' => 'home',
    ], $atts, 'knx_menu_studio' );

    /* ── Auth gate (fail-closed) ── */
    if ( ! function_exists( 'knx_get_session' ) ) {
        wp_safe_redirect( site_url( '/' ) );
        exit;
    }

    $session = knx_get_session();

    if ( ! $session || ! in_array( $session->role, KNX_STUDIO_ALLOWED_ROLES, true ) ) {
        wp_safe_redirect( site_url( '/' ) );
        exit;
    }

    /* ── Shared CSS (injected inline per KNX convention) ── */
    ob_start();
    echo '<link rel="stylesheet" href="' . esc_url( KNX_STUDIO_URL . 'assets/studio.css?v=' . KNX_STUDIO_VERSION ) . '">';

    /* ── Route to the right screen renderer ── */
    switch ( $atts['screen'] ) {
        case 'capture':
            knx_studio_render_capture( $session );
            break;
        case 'harvest':
            knx_studio_render_harvest( $session );
            break;
        default:
            knx_studio_render_home( $session );
            break;
    }

    return ob_get_clean();
}

/* ══════════════════════════════════════════════════════════════
   SCREEN A — Studio Home (tool chooser)
   ══════════════════════════════════════════════════════════════ */
function knx_studio_render_home( $session ) {

    $capture_url = esc_url( site_url( '/menu-studio/capture/' ) );
    $harvest_url = esc_url( site_url( '/menu-studio/harvest/' ) );
    $username    = esc_html( $session->username ?? 'Operator' );

    ?>
    <div class="ms-home">
      <div class="ms-home__header">
        <h1 class="ms-home__title">KNX Menu Studio</h1>
        <p class="ms-home__subtitle">Internal tools for menu data operations</p>
        <span class="ms-home__user">Logged in as <strong><?php echo $username; ?></strong></span>
      </div>

      <div class="ms-home__cards">

        <!-- Migration Capture — active -->
        <a class="ms-tool-card" href="<?php echo $capture_url; ?>">
          <div class="ms-tool-card__icon">📋</div>
          <h2 class="ms-tool-card__title">Migration Capture</h2>
          <p class="ms-tool-card__desc">
            Capture menu data from images and screenshots for new hub
            onboarding. Touch-first, spreadsheet-backed, CSV export.
          </p>
          <span class="ms-tool-card__cta">Open Tool →</span>
        </a>

        <!-- Web Harvest — coming soon -->
        <div class="ms-tool-card ms-tool-card--disabled">
          <div class="ms-tool-card__icon">🌐</div>
          <h2 class="ms-tool-card__title">Web Harvest</h2>
          <p class="ms-tool-card__desc">
            Extract and structure menu data from websites and online
            ordering platforms.
          </p>
          <span class="ms-badge-soon">Coming Soon</span>
        </div>

      </div>

      <a class="ms-home__back" href="<?php echo esc_url( site_url( '/' ) ); ?>">← Back to KNX</a>
    </div>
    <?php
}

/* ══════════════════════════════════════════════════════════════
   SCREEN B — Migration Capture  (V2 — Modal-first architecture)

   Three layers:
     Layer 1  Main Item Builder   (KNX modal clone)
     Layer 2  Floating Image Bubble (draggable, expandable)
     Layer 3  Session List / CSV Preview (lower panel)
   ══════════════════════════════════════════════════════════════ */
function knx_studio_render_capture( $session ) {

    $upload_nonce = wp_create_nonce( 'knx_studio_upload_action' );
    $ajax_url     = admin_url( 'admin-ajax.php' );
    $home_url     = site_url( '/menu-studio/' );
    $username     = esc_html( $session->username ?? 'Operator' );

    echo '<link rel="stylesheet" href="' . esc_url( KNX_STUDIO_URL . 'assets/migration-capture.css?v=' . knx_studio_asset_ver( 'assets/migration-capture.css' ) ) . '">';

    ?>
    <div class="mc-shell"
         data-ajax-url="<?php echo esc_url( $ajax_url ); ?>"
         data-nonce="<?php echo esc_attr( $upload_nonce ); ?>"
         data-role="<?php echo esc_attr( $session->role ); ?>">

      <!-- ═══════════════════════════════════════════════════════
           TOP BAR — Navigation + Category Context + Export
           ═══════════════════════════════════════════════════════ -->
      <header class="mc-topbar">
        <a class="mc-topbar__back" href="<?php echo esc_url( $home_url ); ?>">‹ Studio</a>
        <h1 class="mc-topbar__title">Migration Capture</h1>

        <!-- Category selector (gate for upload) -->
        <div class="mc-cat-bar">
          <div class="mc-cat-bar__select-wrap">
            <input id="ctx-category"
                   class="mc-cat-bar__input"
                   placeholder="Select or create category…"
                   autocomplete="off"
                   list="cat-datalist">
            <datalist id="cat-datalist"></datalist>
          </div>
        </div>

        <div class="mc-topbar__actions">
          <button id="btn-upload-top" class="mc-topbar__upload-btn" disabled title="Select a category first">
            📷 Upload
          </button>
          <button id="btn-new-item" class="mc-topbar__new-item-btn" disabled>+ New Item</button>
          <button id="btn-export-top" class="mc-topbar__export-btn" disabled>Export CSV</button>
          <button id="btn-reset-workspace" class="mc-topbar__reset-btn" title="Reset workspace">⟲</button>
        </div>
      </header>

      <input type="file" id="image-file-input" accept="image/*" style="display:none;">

      <!-- ═══════════════════════════════════════════════════════
           LAYER 1 — MAIN ITEM BUILDER (KNX Modal Clone)
           ═══════════════════════════════════════════════════════ -->
      <div class="mc-workspace">
        <div class="mc-builder" id="mc-builder">

          <!-- Empty state (before category is selected) -->
          <div id="builder-empty" class="mc-builder__empty">
            <div class="mc-builder__empty-icon">📋</div>
            <h2>Migration Capture</h2>
            <p>Select a <strong>category</strong> above to start capturing menu items.</p>
          </div>

          <!-- Builder content (shown when category is active) -->
          <div id="builder-content" class="mc-builder__content" style="display:none;">

            <!-- ── Modal-style dialog ── -->
            <div class="mc-modal-dialog">

              <!-- Hero placeholder (for image crop / thumbnail) -->
              <div class="mc-modal-hero" id="modal-hero" style="display:none;">
                <img id="modal-hero-img" src="" alt="Item reference">
              </div>

              <!-- Header card: Item name + Base price -->
              <div class="mc-modal-header-card">
                <div class="mc-modal-header-card__row">
                  <input id="builder-item-name"
                         class="mc-modal-title-input"
                         placeholder="Item name"
                         autocomplete="off">
                  <button class="mc-pick-btn" data-pick-target="builder-item-name" title="Pick from image">⎗</button>
                </div>
                <div class="mc-modal-price-row">
                  <span class="mc-modal-price-label">$</span>
                  <input id="builder-base-price"
                         class="mc-modal-price-input"
                         placeholder="0.00"
                         inputmode="decimal"
                         autocomplete="off">
                  <button class="mc-pick-btn" data-pick-target="builder-base-price" title="Pick from image">⎗</button>
                </div>
                <div class="mc-modal-desc-row">
                  <textarea id="builder-description"
                            class="mc-modal-desc-input"
                            placeholder="Item description (optional)"
                            rows="2"
                            autocomplete="off"></textarea>
                  <button class="mc-pick-btn" data-pick-target="builder-description" title="Pick from image">⎗</button>
                </div>
              </div>

              <!-- Modifier groups container (JS will append groups here) -->
              <div id="builder-groups" class="mc-modal-groups">
                <!-- JS-rendered modifier group sections -->
              </div>

              <!-- + New Group button -->
              <button id="btn-add-group" class="mc-modal-add-group-btn">+ Add Group</button>

              <!-- ── GROUP DRAFT (inline, appears when adding a group) ── -->
              <div id="group-draft" class="mc-group-draft">

                <div class="mc-group-draft__header">
                  <span class="mc-group-draft__title">New Modifier Group</span>
                  <div class="mc-group-draft__header-actions">
                    <button id="btn-cancel-group" class="mc-group-draft__cancel">Cancel</button>
                  </div>
                </div>

                <div class="mc-group-draft__name-row">
                  <input id="draft-group-name"
                         class="mc-group-draft__name-input"
                         placeholder="Group name (e.g. Choose Your Size)"
                         autocomplete="off">
                  <button class="mc-pick-btn" data-pick-target="draft-group-name" title="Pick from image">⎗</button>
                </div>

                <!-- Semantic chips -->
                <div class="mc-group-draft__chips">
                  <div class="mc-chip-row">
                    <span class="mc-chip-row__label">Action</span>
                    <div class="mc-chip-row__chips" data-chip-group="action">
                      <button class="mc-chip mc-chip--active-add" data-value="add">Add</button>
                      <button class="mc-chip" data-value="remove">Remove</button>
                    </div>
                  </div>
                  <div class="mc-chip-row">
                    <span class="mc-chip-row__label">Required</span>
                    <div class="mc-chip-row__chips" data-chip-group="required">
                      <button class="mc-chip" data-value="1">Yes</button>
                      <button class="mc-chip mc-chip--active" data-value="0">No</button>
                    </div>
                  </div>
                  <div class="mc-chip-row">
                    <span class="mc-chip-row__label">Type</span>
                    <div class="mc-chip-row__chips" data-chip-group="type">
                      <button class="mc-chip" data-value="single">Single</button>
                      <button class="mc-chip mc-chip--active" data-value="multiple">Multi</button>
                    </div>
                  </div>
                </div>

                <!-- Option entry -->
                <div class="mc-group-draft__option-entry">
                  <span class="mc-group-draft__option-label">Add Options</span>
                  <div class="mc-group-draft__option-row">
                    <input id="draft-option-name"
                           class="mc-group-draft__opt-name"
                           placeholder="Option name"
                           autocomplete="off">
                    <button class="mc-pick-btn mc-pick-btn--sm" data-pick-target="draft-option-name" title="Pick from image">⎗</button>
                    <input id="draft-option-price"
                           class="mc-group-draft__opt-price"
                           placeholder="0.00"
                           inputmode="decimal"
                           autocomplete="off">
                    <button class="mc-pick-btn mc-pick-btn--sm" data-pick-target="draft-option-price" title="Pick from image">⎗</button>
                    <button id="btn-quick-fill" class="mc-quick-fill" title="$0.00">$0</button>
                    <button id="btn-add-option" class="mc-group-draft__add-opt">+</button>
                  </div>
                </div>

                <!-- Options preview (grid like real modal) -->
                <div id="draft-options-grid" class="mc-modal-options">
                  <!-- JS-rendered option cards -->
                </div>

                <button id="btn-commit-group" class="mc-group-draft__commit" disabled>
                  Commit Group ↓
                </button>

              </div><!-- /group-draft -->

            </div><!-- /mc-modal-dialog -->

            <!-- Builder footer: Add to List -->
            <div class="mc-builder__footer">
              <button id="btn-add-to-list" class="mc-builder__add-btn" disabled>
                Add to List
              </button>
              <button id="btn-clear-item" class="mc-builder__clear-btn">Clear Item</button>
            </div>

          </div><!-- /builder-content -->

        </div><!-- /mc-builder -->

        <!-- ═══════════════════════════════════════════════════════
             LAYER 3 — SESSION LIST / CSV PREVIEW
             ═══════════════════════════════════════════════════════ -->
        <div class="mc-session" id="mc-session">
          <div class="mc-session__header">
            <span class="mc-session__title" id="session-title">Session — 0 items</span>
            <div class="mc-session__filters">
              <input id="session-filter-search"
                     class="mc-session__search"
                     placeholder="Search items…"
                     autocomplete="off">
            </div>
            <div class="mc-session__actions">
              <button id="btn-export-bottom" class="mc-session__export-btn" disabled>Export CSV</button>
            </div>
          </div>

          <div class="mc-session__scroll">
            <div id="session-empty" class="mc-session__empty">
              Build items above, then "Add to List" to see them here.
            </div>
            <table id="session-table" class="mc-session-table" style="display:none;">
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Item Name</th>
                  <th>Description</th>
                  <th>Base Price</th>
                  <th>Groups</th>
                  <th>Status</th>
                  <th class="mc-session-table__th-actions"></th>
                </tr>
              </thead>
              <tbody id="session-tbody"></tbody>
            </table>
          </div>
        </div>

      </div><!-- /mc-workspace -->

      <!-- ═══════════════════════════════════════════════════════
           LAYER 2 — FLOATING IMAGE BUBBLE
           ═══════════════════════════════════════════════════════ -->
      <div id="img-bubble" class="mc-bubble" style="display:none;">

        <!-- Minimized state: draggable thumbnail -->
        <div class="mc-bubble__mini" id="bubble-mini">
          <img id="bubble-mini-img" class="mc-bubble__mini-img" src="" alt="Menu ref">
          <span class="mc-bubble__mini-badge">📷</span>
        </div>

        <!-- Expanded state: large overlay with image + selection -->
        <div class="mc-bubble__expanded" id="bubble-expanded" style="display:none;">
          <div class="mc-bubble__expanded-header">
            <span class="mc-bubble__expanded-title">Source Image</span>
            <div class="mc-bubble__expanded-actions">
              <button id="btn-bubble-replace" class="mc-bubble__action-btn">Replace</button>
              <button id="btn-bubble-minimize" class="mc-bubble__action-btn">Minimize</button>
              <button id="btn-bubble-close" class="mc-bubble__action-btn mc-bubble__action-btn--close">×</button>
            </div>
          </div>
          <div class="mc-bubble__expanded-body" id="bubble-expanded-body">
            <img id="bubble-expanded-img" class="mc-bubble__expanded-img" src="" alt="Menu reference">
            <!-- OCR selection canvas overlay -->
            <canvas id="ocr-canvas" class="mc-bubble__ocr-canvas"></canvas>
          </div>
          <div class="mc-bubble__expanded-footer" id="bubble-expanded-footer">
            <span class="mc-bubble__ocr-hint" id="ocr-hint">Draw a rectangle over text to extract it</span>
            <div class="mc-bubble__capture-bar">
              <button id="btn-block-capture" class="mc-bubble__block-capture-btn">📋 Capture Block</button>
            </div>
          </div>

          <!-- Visual feedback overlay for group capture -->
          <div id="group-capture-overlay" class="mc-group-capture-overlay" style="display:none;">
            <div class="mc-group-capture-overlay__content">
              <div class="mc-group-capture-overlay__icon">📐</div>
              <div class="mc-group-capture-overlay__title">Draw Rectangle Around Group</div>
              <div class="mc-group-capture-overlay__hint">Include: Group name, requirement badge (e.g., "1 Required"), and all option names with prices</div>
              <button id="btn-cancel-group-capture" class="mc-group-capture-overlay__cancel">Cancel</button>
            </div>
          </div>
        </div>

      </div><!-- /img-bubble -->

      <!-- ═══════════════════════════════════════════════════════
           EYE PREVIEW MODAL (item preview like real KNX modal)
           ═══════════════════════════════════════════════════════ -->
      <div id="eye-preview-overlay" class="mc-eye-overlay" style="display:none;">
        <div class="mc-eye-overlay__backdrop"></div>
        <div class="mc-eye-overlay__dialog">
          <button id="btn-eye-close" class="mc-eye-overlay__close">×</button>
          <div id="eye-preview-body" class="mc-eye-overlay__body">
            <!-- JS renders a read-only KNX modal clone here -->
          </div>
        </div>
      </div>

    </div><!-- /mc-shell -->

    <div id="mc-autosave-badge" class="mc-autosave-badge">Draft saved</div>
    <div id="mc-toast" class="mc-toast"></div>

    <script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
    <script src="<?php echo esc_url( KNX_STUDIO_URL . 'assets/migration-capture.js?v=' . knx_studio_asset_ver( 'assets/migration-capture.js' ) ); ?>"></script>
    <?php
}

/* ══════════════════════════════════════════════════════════════
   SCREEN C — Web Harvest (placeholder)
   ══════════════════════════════════════════════════════════════ */
function knx_studio_render_harvest( $session ) {

    $home_url = site_url( '/menu-studio/' );

    ?>
    <div class="ms-placeholder">
      <div class="ms-placeholder__icon">🌐</div>
      <h1 class="ms-placeholder__title">Web Harvest</h1>
      <p class="ms-placeholder__desc">
        Extract and structure menu data from websites and online
        ordering platforms. This tool is not yet available.
      </p>
      <a class="ms-placeholder__back" href="<?php echo esc_url( $home_url ); ?>">← Studio Home</a>
    </div>
    <?php
}

/* ══════════════════════════════════════════════════════════════
   2. AJAX UPLOAD HANDLER
      Action: knx_studio_upload
      Nonce:  knx_studio_upload_action
   ══════════════════════════════════════════════════════════════ */
add_action( 'wp_ajax_knx_studio_upload', 'knx_menu_studio_handle_upload' );

function knx_menu_studio_handle_upload() {

    /* Auth: session + role */
    if ( function_exists( 'knx_get_session' ) ) {
        $session = knx_get_session();
        if ( ! $session || ! in_array( $session->role, KNX_STUDIO_ALLOWED_ROLES, true ) ) {
            wp_send_json_error( [ 'error' => 'Unauthorized.' ], 403 );
        }
    }

    /* Nonce */
    if ( empty( $_REQUEST['nonce'] ) ||
         ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ), 'knx_studio_upload_action' )
    ) {
        wp_send_json_error( [ 'error' => 'Invalid nonce.' ], 403 );
    }

    /* File presence */
    if ( empty( $_FILES['image'] ) || $_FILES['image']['error'] !== UPLOAD_ERR_OK ) {
        wp_send_json_error( [ 'error' => 'No file received.' ], 400 );
    }

    $file = $_FILES['image'];

    /* Size: max 10 MB */
    if ( $file['size'] > 10 * 1024 * 1024 ) {
        wp_send_json_error( [ 'error' => 'File too large. Max 10 MB.' ], 413 );
    }

    /* MIME validation */
    $allowed = [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp' ];
    $finfo   = new finfo( FILEINFO_MIME_TYPE );
    $mime    = $finfo->file( $file['tmp_name'] );

    if ( ! in_array( $mime, $allowed, true ) ) {
        wp_send_json_error( [ 'error' => 'Only image files accepted.' ], 415 );
    }

    /* Destination */
    $upload_dir = wp_upload_dir();
    $dest_dir   = trailingslashit( $upload_dir['basedir'] ) . 'knx-studio-temp/';
    $dest_url   = trailingslashit( $upload_dir['baseurl'] ) . 'knx-studio-temp/';

    if ( ! is_dir( $dest_dir ) ) {
        wp_mkdir_p( $dest_dir );
        file_put_contents( $dest_dir . 'index.php', '<?php // Silence is golden' );
    }

    $ext_map  = [
        'image/jpeg' => 'jpg', 'image/png'  => 'png',
        'image/gif'  => 'gif', 'image/webp' => 'webp', 'image/bmp' => 'bmp',
    ];
    $ext      = $ext_map[ $mime ] ?? 'jpg';
    $filename = wp_generate_password( 16, false ) . '.' . $ext;

    if ( ! move_uploaded_file( $file['tmp_name'], $dest_dir . $filename ) ) {
        wp_send_json_error( [ 'error' => 'Failed to save file.' ], 500 );
    }

    wp_send_json_success( [ 'url' => $dest_url . $filename ] );
}
