/* ============================================================
   KNX Menu Studio — Migration Capture V2
   Modal-first builder · Floating image bubble · Session list
   Eye preview · Autosave · OCR area selection
   ============================================================ */
(function () {
  'use strict';

  /* ────────────────────────────────────────────────────────────
     1. STATE MODEL
     ──────────────────────────────────────────────────────────── */

  /* Session items — each item has groups with options */
  let sessionItems = [];  // [ { id, category, name, basePrice, groups: [ { id, name, action, required, type, options: [{ id, name, price, action }] } ] } ]
  let nextItemId   = 1;
  let nextGroupId  = 1;
  let nextOptionId = 1;

  /* Current item draft in the builder */
  let currentDraft = null;   // same shape as sessionItems entry, or null

  /* Current group draft (while adding a group) */
  let groupDraft = null;     // { name, action, required, type, options: [] }

  /* Category memory (locally created categories) */
  let categories = [];       // string[]

  /* OCR pick mode */
  let pickTarget = null;          // DOM id or dynamic target to fill
  let blockCaptureMode = false;   // true = next OCR result is treated as a block capture
  let blockCaptureForGroup = false; // true = next block OCR result is for the active group draft
  let lastRawOcrText = '';        // last raw OCR text kept only as secondary debug/fallback

  /* Autosave key */
  const AUTOSAVE_KEY = 'knx_studio_mc_v2';

  /* ────────────────────────────────────────────────────────────
     2. DOM REFERENCES
     ──────────────────────────────────────────────────────────── */

  const $ = s => document.querySelector(s);
  const $$ = s => document.querySelectorAll(s);

  const shell = $('.mc-shell');
  if (!shell) return;

  const dom = {
    /* Topbar */
    ctxCategory:     $('#ctx-category'),
    catDatalist:     $('#cat-datalist'),
    btnUploadTop:    $('#btn-upload-top'),
    btnNewItem:      $('#btn-new-item'),
    btnExportTop:    $('#btn-export-top'),
    btnResetWS:      $('#btn-reset-workspace'),
    imageFileInput:  $('#image-file-input'),

    /* Builder */
    builder:         $('#mc-builder'),
    builderEmpty:    $('#builder-empty'),
    builderContent:  $('#builder-content'),
    builderItemName: $('#builder-item-name'),
    builderBasePrice:$('#builder-base-price'),
    builderDesc:     $('#builder-description'),
    builderGroups:   $('#builder-groups'),
    btnAddGroup:     $('#btn-add-group'),
    btnAddToList:    $('#btn-add-to-list'),
    btnClearItem:    $('#btn-clear-item'),

    /* Modal hero */
    modalHero:       $('#modal-hero'),
    modalHeroImg:    $('#modal-hero-img'),

    /* Group draft */
    groupDraftEl:     $('#group-draft'),
    draftGroupName:   $('#draft-group-name'),
    btnCancelGroup:   $('#btn-cancel-group'),
    btnShowRawOcr:    $('#btn-show-raw-ocr'),
    draftOptionName:  $('#draft-option-name'),
    draftOptionPrice: $('#draft-option-price'),
    btnQuickFill:     $('#btn-quick-fill'),
    btnAddOption:     $('#btn-add-option'),
    draftOptionsGrid: $('#draft-options-grid'),
    btnCommitGroup:   $('#btn-commit-group'),

    /* Session list */
    sessionTitle:    $('#session-title'),
    sessionEmpty:    $('#session-empty'),
    sessionTable:    $('#session-table'),
    sessionTbody:    $('#session-tbody'),
    sessionSearch:   $('#session-filter-search'),
    btnExportBottom: $('#btn-export-bottom'),

    /* Image bubble */
    imgBubble:       $('#img-bubble'),
    bubbleMini:      $('#bubble-mini'),
    bubbleMiniImg:   $('#bubble-mini-img'),
    bubbleExpanded:  $('#bubble-expanded'),
    bubbleExpandedImg:$('#bubble-expanded-img'),
    bubbleExpandedBody:$('#bubble-expanded-body'),
    ocrCanvas:       $('#ocr-canvas'),
    ocrHint:         $('#ocr-hint'),
    btnBlockCapture: $('#btn-block-capture'),
    ocrPanel:        $('#ocr-capture-panel'),
    ocrPanelText:    $('#ocr-capture-text'),
    btnOcrPanelClose:$('#btn-ocr-panel-close'),
    btnBubbleReplace:$('#btn-bubble-replace'),
    btnBubbleMinimize:$('#btn-bubble-minimize'),
    btnBubbleClose:  $('#btn-bubble-close'),

    /* Eye preview */
    eyeOverlay:      $('#eye-preview-overlay'),
    eyeBody:         $('#eye-preview-body'),
    btnEyeClose:     $('#btn-eye-close'),

    /* Toast */
    toast:           $('#mc-toast'),
    autosaveBadge:   $('#mc-autosave-badge'),
  };

  const ajaxUrl = shell.dataset.ajaxUrl || '';
  const nonce   = shell.dataset.nonce   || '';

  /* ────────────────────────────────────────────────────────────
     3. CATEGORY MANAGEMENT
     ──────────────────────────────────────────────────────────── */

  function updateCatDatalist() {
    dom.catDatalist.innerHTML = categories.map(c =>
      '<option value="' + escAttr(c) + '">'
    ).join('');
  }

  function getCategory() {
    return (dom.ctxCategory.value || '').trim();
  }

  function onCategoryChange() {
    const cat = getCategory();
    const hasCategory = cat.length > 0;

    /* Add to memory if new */
    if (hasCategory && !categories.includes(cat)) {
      categories.push(cat);
      updateCatDatalist();
    }

    /* Gate: unlock upload + new item */
    dom.btnUploadTop.disabled = !hasCategory;
    dom.btnNewItem.disabled = !hasCategory;

    /* If builder is empty, show content */
    if (hasCategory && !currentDraft) {
      startNewItem();
    }
    if (currentDraft) {
      currentDraft.category = cat;
    }

    syncAll();
    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     4. ITEM DRAFT LIFECYCLE
     ──────────────────────────────────────────────────────────── */

  function freshItemDraft() {
    return {
      id:          nextItemId++,
      category:    getCategory(),
      name:        '',
      description: '',
      basePrice:   '',
      groups:      [],
      imageUrl:    currentImageUrl || '',
    };
  }

  function startNewItem() {
    currentDraft = freshItemDraft();
    dom.builderEmpty.style.display = 'none';
    dom.builderContent.style.display = '';
    dom.builderItemName.value = '';
    dom.builderBasePrice.value = '';
    if (dom.builderDesc) dom.builderDesc.value = '';
    dom.builderGroups.innerHTML = '';
  }

  function clearCurrentItem() {
    if (currentDraft && currentDraft.groups.length > 0) {
      if (!confirm('Clear current item and all its groups?')) return;
    }
    currentDraft = freshItemDraft();
    dom.builderItemName.value = '';
    dom.builderBasePrice.value = '';
    if (dom.builderDesc) dom.builderDesc.value = '';
    dom.builderGroups.innerHTML = '';
    scheduleAutosave();
  }

  function addItemToList() {
    if (!currentDraft) return;
    const cat  = getCategory();
    const name = dom.builderItemName.value.trim();
    if (!cat) { toast('Select a category first.'); return; }
    if (!name) { toast('Enter an item name.'); dom.builderItemName.focus(); return; }

    currentDraft.category    = cat;
    currentDraft.name        = name;
    currentDraft.description = dom.builderDesc ? dom.builderDesc.value.trim() : '';
    currentDraft.basePrice   = dom.builderBasePrice.value.trim() || '0.00';

    sessionItems.push(currentDraft);
    const addedName = currentDraft.name;
    const groupCount = currentDraft.groups.length;

    /* Start fresh item (keep category) */
    startNewItem();
    renderSessionList();
    syncAll();
    toast('"' + addedName + '" added — ' + groupCount + ' group' + (groupCount !== 1 ? 's' : '') + '.');
    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     5. GROUP DRAFT LIFECYCLE
     ──────────────────────────────────────────────────────────── */

  function freshGroupDraft() {
    return {
      name:     '',
      action:   'add',
      required: '0',
      type:     'multiple',
      options:  [],
    };
  }

  function openGroupDraft(skipCapture) {
    groupDraft = freshGroupDraft();

    dom.groupDraftEl.classList.add('active');
    dom.btnAddGroup.style.display = 'none';

    dom.draftGroupName.value = '';
    dom.draftOptionName.value = '';
    dom.draftOptionPrice.value = '';
    dom.draftOptionsGrid.innerHTML = '';
    dom.btnCommitGroup.disabled = true;

    if (dom.btnShowRawOcr) dom.btnShowRawOcr.style.display = 'none';
    lastRawOcrText = '';
    hideOcrPanel();

    resetChipGroup('action', 'add');
    resetChipGroup('required', '0');
    resetChipGroup('type', 'multiple');

    /* If an image exists, Add Group must launch full block capture immediately */
    if (currentImageUrl && !skipCapture) {
      activateBlockCaptureForGroup();
    } else {
      dom.draftGroupName.focus();
    }
  }

  function closeGroupDraft() {
    groupDraft = null;

    dom.groupDraftEl.classList.remove('active');
    dom.btnAddGroup.style.display = '';

    if (dom.btnShowRawOcr) dom.btnShowRawOcr.style.display = 'none';
    lastRawOcrText = '';
    hideOcrPanel();

    /* Cancel any pending block capture for this group */
    if (blockCaptureMode && blockCaptureForGroup) {
      deactivateBlockCapture();
      showBubbleMini();
    }
  }

  function commitGroup() {
    if (!groupDraft || groupDraft.options.length === 0) return;
    if (!currentDraft) return;
    const gName = dom.draftGroupName.value.trim();
    if (!gName) { toast('Enter a group name.'); dom.draftGroupName.focus(); return; }

    const group = {
      id:       nextGroupId++,
      name:     gName,
      action:   groupDraft.action,
      required: groupDraft.required,
      type:     groupDraft.type,
      options:  groupDraft.options.map(opt => ({
        id:     nextOptionId++,
        name:   opt.name,
        price:  opt.price,
        action: opt.action,
      })),
    };

    currentDraft.groups.push(group);
    closeGroupDraft();
    renderBuilderGroups();
    syncAddToListBtn();
    toast('Group "' + gName + '" added — ' + group.options.length + ' options.');
    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     6. OPTION DRAFT (within group draft)
     ──────────────────────────────────────────────────────────── */

  function addOptionToDraft() {
    if (!groupDraft) return;
    const name = dom.draftOptionName.value.trim();
    if (!name) { toast('Enter option name.'); dom.draftOptionName.focus(); return; }
    const priceRaw = dom.draftOptionPrice.value.trim();
    const price = (parseFloat(priceRaw) || 0).toFixed(2);

    groupDraft.options.push({
      name,
      price,
      action: groupDraft.action,
    });

    dom.draftOptionName.value = '';
    dom.draftOptionPrice.value = groupDraft.action === 'remove' ? '0.00' : '';
    dom.draftOptionName.focus();
    renderDraftOptionsGrid();
    dom.btnCommitGroup.disabled = false;
  }

  function removeDraftOption(idx) {
    if (!groupDraft) return;
    groupDraft.options.splice(idx, 1);
    renderDraftOptionsGrid();
    dom.btnCommitGroup.disabled = groupDraft.options.length === 0;
    scheduleAutosave();
  }

  function renderDraftOptionsGrid() {
    if (!groupDraft) {
      dom.draftOptionsGrid.innerHTML = '';
      return;
    }

    dom.draftOptionsGrid.innerHTML = groupDraft.options.map((opt, i) => {
      const price = (parseFloat(opt.price) || 0).toFixed(2);
      const isRemove = opt.action === 'remove';
      const actionClass = isRemove ? ' mc-draft-option-editor--remove' : '';
      const actionLabel = isRemove ? 'remove' : 'add';

      return `
        <div class="mc-draft-option-editor${actionClass}" data-draft-opt-idx="${i}">
          <div class="mc-draft-option-editor__top">
            <span class="mc-draft-option-editor__badge">${actionLabel}</span>
            <button class="mc-draft-option-delete" data-remove-draft-opt="${i}" title="Delete option">×</button>
          </div>

          <div class="mc-draft-option-editor__row">
            <div class="mc-draft-option-editor__cell mc-draft-option-editor__cell--name">
              <label>Option Name</label>
              <div class="mc-input-with-pick">
                <input
                  type="text"
                  class="mc-draft-option-input"
                  data-draft-opt-input="name"
                  data-draft-opt-idx="${i}"
                  value="${escAttr(opt.name)}"
                  autocomplete="off">
                <button
                  class="mc-pick-btn mc-pick-btn--sm"
                  data-pick-target="draft-option-name:${i}"
                  title="Pick option name from image">⎗</button>
              </div>
            </div>

            <div class="mc-draft-option-editor__cell mc-draft-option-editor__cell--price">
              <label>Price</label>
              <div class="mc-input-with-pick">
                <input
                  type="text"
                  class="mc-draft-option-input"
                  data-draft-opt-input="price"
                  data-draft-opt-idx="${i}"
                  value="${price}"
                  inputmode="decimal"
                  autocomplete="off">
                <button
                  class="mc-pick-btn mc-pick-btn--sm"
                  data-pick-target="draft-option-price:${i}"
                  title="Pick option price from image">⎗</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  /* ────────────────────────────────────────────────────────────
     7. RENDER BUILDER GROUPS (committed groups)
     ──────────────────────────────────────────────────────────── */

  function renderBuilderGroups() {
    if (!currentDraft) { dom.builderGroups.innerHTML = ''; return; }

    dom.builderGroups.innerHTML = currentDraft.groups.map(g => {
      const reqBadge = g.required === '1'
        ? '<span class="mc-modal-group-badge mc-modal-group-badge--required">Required</span>'
        : '<span class="mc-modal-group-badge mc-modal-group-badge--type">Optional</span>';
      const typeBadge = '<span class="mc-modal-group-badge mc-modal-group-badge--type">' + esc(g.type) + '</span>';
      const actionBadge = g.action === 'remove'
        ? '<span class="mc-modal-group-badge mc-modal-group-badge--action-remove">remove</span>'
        : '<span class="mc-modal-group-badge mc-modal-group-badge--action-add">add</span>';

      const optionsHtml = g.options.map(opt => {
        const isRemove = opt.action === 'remove';
        const removeCls = isRemove ? ' mc-modal-option--remove' : '';
        const ctaText = isRemove ? 'Exclude' : 'Add';
        const priceText = parseFloat(opt.price) > 0 ? ' $' + opt.price : '';
        return '<div class="mc-modal-option' + removeCls + '">'
          + '<span class="mc-modal-option-label">' + esc(opt.name) + '</span>'
          + '<span class="mc-modal-option-cta">' + ctaText + '<strong class="mc-modal-option-cta-price">' + priceText + '</strong></span>'
          + '</div>';
      }).join('');

      return '<section class="mc-modal-group" data-group-id="' + g.id + '">'
        + '<div class="mc-modal-group-header">'
        + '<h3 class="mc-modal-group-title">' + esc(g.name) + '</h3>'
        + '<div class="mc-modal-group-meta">' + reqBadge + typeBadge + actionBadge
        + '<button class="mc-modal-group-delete" data-delete-group="' + g.id + '" title="Remove group">×</button>'
        + '</div></div>'
        + '<div class="mc-modal-options">' + optionsHtml + '</div>'
        + '</section>';
    }).join('');
  }

  function deleteBuilderGroup(groupId) {
    if (!currentDraft) return;
    currentDraft.groups = currentDraft.groups.filter(g => g.id !== groupId);
    renderBuilderGroups();
    syncAddToListBtn();
    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     8. CHIP SWITCHING
     ──────────────────────────────────────────────────────────── */

  function initChips() {
    $$('[data-chip-group]').forEach(container => {
      const group = container.dataset.chipGroup;
      container.querySelectorAll('.mc-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          container.querySelectorAll('.mc-chip').forEach(c => c.className = 'mc-chip');
          if (group === 'action') {
            chip.classList.add(chip.dataset.value === 'add' ? 'mc-chip--active-add' : 'mc-chip--active-remove');
          } else {
            chip.classList.add('mc-chip--active');
          }
          if (groupDraft) {
            groupDraft[group] = chip.dataset.value;
          }
          if (group === 'action' && groupDraft && groupDraft.action === 'remove') {
            dom.draftOptionPrice.value = '0.00';
          }
        });
      });
    });
  }

  function resetChipGroup(group, value) {
    const container = $('[data-chip-group="' + group + '"]');
    if (!container) return;
    container.querySelectorAll('.mc-chip').forEach(c => {
      c.className = 'mc-chip';
      if (c.dataset.value === value) {
        if (group === 'action') {
          c.classList.add(value === 'add' ? 'mc-chip--active-add' : 'mc-chip--active-remove');
        } else {
          c.classList.add('mc-chip--active');
        }
      }
    });
  }

  /* ────────────────────────────────────────────────────────────
     9. SESSION LIST
     ──────────────────────────────────────────────────────────── */

  function renderSessionList() {
    const search = (dom.sessionSearch.value || '').trim().toLowerCase();
    const filtered = search
      ? sessionItems.filter(it => it.name.toLowerCase().includes(search) || it.category.toLowerCase().includes(search))
      : sessionItems;

    dom.sessionTitle.textContent = 'Session — ' + sessionItems.length + ' item' + (sessionItems.length !== 1 ? 's' : '');

    if (filtered.length === 0) {
      dom.sessionEmpty.style.display = '';
      dom.sessionTable.style.display = 'none';
      return;
    }

    dom.sessionEmpty.style.display = 'none';
    dom.sessionTable.style.display = '';

    dom.sessionTbody.innerHTML = filtered.map(it => {
      const optCount = it.groups.reduce((sum, g) => sum + g.options.length, 0);
      const groupsText = it.groups.length + ' group' + (it.groups.length !== 1 ? 's' : '') + ' · ' + optCount + ' opt';
      const status = itemStatus(it);
      return '<tr data-session-item-id="' + it.id + '">'
        + '<td><input class="mc-session-table__editable" data-field="category" value="' + escAttr(it.category) + '"></td>'
        + '<td><input class="mc-session-table__editable" data-field="name" value="' + escAttr(it.name) + '"></td>'
        + '<td><input class="mc-session-table__editable mc-session-table__editable--desc" data-field="description" value="' + escAttr(it.description || '') + '" placeholder="—"></td>'
        + '<td><input class="mc-session-table__editable" data-field="basePrice" value="' + escAttr(it.basePrice) + '" style="width:70px;" inputmode="decimal"></td>'
        + '<td><span class="mc-session-table__groups-count">' + groupsText + '</span></td>'
        + '<td><span class="mc-session-table__status mc-session-table__status--' + status.cls + '">' + status.label + '</span></td>'
        + '<td><div class="mc-session-table__action-btns">'
        + '<button class="mc-session-table__eye" data-eye-item="' + it.id + '" title="Preview">👁</button>'
        + '<button class="mc-session-table__delete" data-delete-item="' + it.id + '" title="Delete">×</button>'
        + '</div></td>'
        + '</tr>';
    }).join('');
  }

  function deleteSessionItem(id) {
    sessionItems = sessionItems.filter(it => it.id !== id);
    renderSessionList();
    syncAll();
    scheduleAutosave();
    toast('Item removed from session.');
  }

  /* ────────────────────────────────────────────────────────────
     10. EYE PREVIEW
     ──────────────────────────────────────────────────────────── */

  function openEyePreview(itemId) {
    const item = sessionItems.find(it => it.id === itemId);
    if (!item) return;

    /* Build read-only modal clone */
    let html = '<div class="mc-modal-dialog">';

    /* Header card */
    html += '<div class="mc-modal-header-card">';
    html += '<div class="mc-modal-header-card__row"><input class="mc-modal-title-input" value="' + escAttr(item.name) + '" readonly></div>';
    if (item.description) {
      html += '<div class="mc-modal-desc-row"><textarea class="mc-modal-desc-input" readonly>' + esc(item.description) + '</textarea></div>';
    }
    html += '<div class="mc-modal-price-row"><span class="mc-modal-price-label">$</span><input class="mc-modal-price-input" value="' + escAttr(item.basePrice) + '" readonly></div>';
    html += '</div>';

    /* Groups */
    item.groups.forEach(g => {
      const reqBadge = g.required === '1'
        ? '<span class="mc-modal-group-badge mc-modal-group-badge--required">Required</span>'
        : '<span class="mc-modal-group-badge mc-modal-group-badge--type">Optional</span>';
      const typeBadge = '<span class="mc-modal-group-badge mc-modal-group-badge--type">' + esc(g.type) + '</span>';

      html += '<section class="mc-modal-group"><div class="mc-modal-group-header">';
      html += '<h3 class="mc-modal-group-title">' + esc(g.name) + '</h3>';
      html += '<div class="mc-modal-group-meta">' + reqBadge + typeBadge + '</div></div>';
      html += '<div class="mc-modal-options">';
      g.options.forEach(opt => {
        const isRemove = opt.action === 'remove';
        const removeCls = isRemove ? ' mc-modal-option--remove' : '';
        const ctaText = isRemove ? 'Exclude' : 'Add';
        const priceText = parseFloat(opt.price) > 0 ? ' $' + opt.price : '';
        html += '<div class="mc-modal-option' + removeCls + '">';
        html += '<span class="mc-modal-option-label">' + esc(opt.name) + '</span>';
        html += '<span class="mc-modal-option-cta">' + ctaText + '<strong class="mc-modal-option-cta-price">' + priceText + '</strong></span>';
        html += '</div>';
      });
      html += '</div></section>';
    });

    html += '</div>';

    dom.eyeBody.innerHTML = html;
    dom.eyeOverlay.style.display = '';
  }

  function closeEyePreview() {
    dom.eyeOverlay.style.display = 'none';
    dom.eyeBody.innerHTML = '';
  }

  /* ────────────────────────────────────────────────────────────
     11. CSV EXPORT
     ──────────────────────────────────────────────────────────── */

  const CSV_COLS = ['category_name','item_name','item_description','group_name','group_required','group_type','option_name','option_price','option_action'];

  function exportCSV() {
    if (sessionItems.length === 0) { toast('No items to export.'); return; }

    const rows = [];
    sessionItems.forEach(item => {
      if (item.groups.length === 0) {
        /* Item-only row (no modifiers yet) */
        rows.push({
          category_name:    item.category,
          item_name:        item.name,
          item_description: item.description || '',
          group_name:       '',
          group_required:   '',
          group_type:       '',
          option_name:      '',
          option_price:     item.basePrice,
          option_action:    '',
        });
      } else {
        item.groups.forEach(group => {
          group.options.forEach(opt => {
            rows.push({
              category_name:  item.category,
              item_name:      item.name,
              group_name:     group.name,
              group_required: group.required,
              group_type:     group.type,
              option_name:    opt.name,
              option_price:   opt.price,
              option_action:  opt.action,
            });
          });
        });
      }
    });

    if (rows.length === 0) { toast('Nothing to export.'); return; }

    const header = CSV_COLS.join(',');
    const body = rows.map(r => CSV_COLS.map(c => csvCell(r[c])).join(',')).join('\n');
    const csv = header + '\n' + body + '\n';

    const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = 'migration-' + slug(getCategory() || 'export') + '-' + dateStr + '.csv';

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.style.display = 'none';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast('Exported ' + rows.length + ' rows → ' + filename);
  }

  function csvCell(v) {
    const s = String(v == null ? '' : v);
    return (s.includes(',') || s.includes('"') || s.includes('\n'))
      ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  /* ────────────────────────────────────────────────────────────
     12. IMAGE UPLOAD + BUBBLE
     ──────────────────────────────────────────────────────────── */

  let currentImageUrl = '';
  let bubbleState = 'hidden'; // hidden | mini | expanded
  let bubblePos = { x: 16, y: 80 };

  function initImageUpload() {
    dom.btnUploadTop.addEventListener('click', () => dom.imageFileInput.click());

    dom.imageFileInput.addEventListener('change', () => {
      const file = dom.imageFileInput.files[0];
      if (!file) return;
      if (!file.type.startsWith('image/')) { toast('Only image files.'); return; }
      if (file.size > 10 * 1024 * 1024) { toast('Max 10 MB.'); return; }

      if (ajaxUrl && nonce) {
        const fd = new FormData();
        fd.append('image', file);
        fd.append('action', 'knx_studio_upload');
        fd.append('nonce', nonce);
        fetch(ajaxUrl, { method: 'POST', body: fd })
          .then(r => r.ok ? r.json() : Promise.reject())
          .then(data => {
            const url = data?.data?.url || data?.url;
            if (data.success && url) { setImage(url); return; }
            throw new Error();
          })
          .catch(() => localFallback(file));
      } else {
        localFallback(file);
      }
      dom.imageFileInput.value = '';
    });
  }

  function localFallback(file) {
    const reader = new FileReader();
    reader.onload = e => setImage(e.target.result);
    reader.readAsDataURL(file);
  }

  function setImage(url) {
    currentImageUrl = url;
    if (currentDraft) currentDraft.imageUrl = url;

    /* Set all image sources */
    dom.bubbleMiniImg.src = url;
    dom.bubbleExpandedImg.src = url;
    dom.modalHeroImg.src = url;
    dom.modalHero.style.display = '';

    /* Show bubble expanded first time */
    showBubbleExpanded();
    toast('Image loaded.');
    initOCR();
    scheduleAutosave();
  }

  function showBubbleMini() {
    bubbleState = 'mini';
    dom.imgBubble.style.display = '';
    dom.bubbleMini.style.display = '';
    dom.bubbleExpanded.style.display = 'none';
    dom.imgBubble.style.left = bubblePos.x + 'px';
    dom.imgBubble.style.top = bubblePos.y + 'px';
  }

  function showBubbleExpanded() {
    bubbleState = 'expanded';
    dom.imgBubble.style.display = '';
    dom.bubbleMini.style.display = 'none';
    dom.bubbleExpanded.style.display = '';
    dom.imgBubble.style.left = '';
    dom.imgBubble.style.top = '';
    syncOcrCanvas();
  }

  function hideBubble() {
    bubbleState = 'hidden';
    dom.imgBubble.style.display = 'none';
  }

  /* ── Drag logic for minimized bubble ── */
  function initBubbleDrag() {
    let dragging = false;
    let startX, startY, startLeft, startTop;

    dom.bubbleMini.addEventListener('pointerdown', e => {
      if (bubbleState !== 'mini') return;
      dragging = true;
      startX = e.clientX; startY = e.clientY;
      startLeft = bubblePos.x; startTop = bubblePos.y;
      dom.bubbleMini.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    document.addEventListener('pointermove', e => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      bubblePos.x = Math.max(0, Math.min(window.innerWidth - 70, startLeft + dx));
      bubblePos.y = Math.max(0, Math.min(window.innerHeight - 70, startTop + dy));
      dom.imgBubble.style.left = bubblePos.x + 'px';
      dom.imgBubble.style.top = bubblePos.y + 'px';
    });

    document.addEventListener('pointerup', e => {
      if (!dragging) return;
      dragging = false;
      const dx = Math.abs(e.clientX - startX);
      const dy = Math.abs(e.clientY - startY);
      /* If barely moved, treat as tap → expand */
      if (dx < 6 && dy < 6) {
        showBubbleExpanded();
      } else {
        /* Snap to nearest edge */
        const midX = window.innerWidth / 2;
        bubblePos.x = bubblePos.x + 35 < midX ? 12 : window.innerWidth - 76;
        dom.imgBubble.style.left = bubblePos.x + 'px';
      }
    });
  }

  /* ────────────────────────────────────────────────────────────
     13. OCR — AREA SELECTION ON EXPANDED IMAGE
     ──────────────────────────────────────────────────────────── */

  let ocrWorker = null;
  let isOcrReady = false;

  async function initOCR() {
    if (ocrWorker || !window.Tesseract) return;
    try {
      toast('Loading OCR engine…');
      ocrWorker = await Tesseract.createWorker('eng', 1, {
        logger: m => {
          if (m.status === 'recognizing text') {
            toast('Recognizing… ' + (m.progress * 100).toFixed(0) + '%');
          }
        }
      });
      isOcrReady = true;
      toast('OCR ready. Draw on image to extract text.');
    } catch (err) {
      console.error('OCR init failed:', err);
      toast('OCR unavailable.');
    }
  }

  function syncOcrCanvas() {
    const img = dom.bubbleExpandedImg;
    const body = dom.bubbleExpandedBody;
    if (!img.naturalWidth) {
      img.onload = () => syncOcrCanvas();
      return;
    }
    dom.ocrCanvas.width = body.clientWidth;
    dom.ocrCanvas.height = body.clientHeight;
  }

  function initOcrSelection() {
    const canvas = dom.ocrCanvas;
    const ctx = canvas.getContext('2d');
    let drawing = false;
    let sx, sy;

    canvas.addEventListener('pointerdown', e => {
      drawing = true;
      const rect = canvas.getBoundingClientRect();
      sx = e.clientX - rect.left;
      sy = e.clientY - rect.top;
      canvas.setPointerCapture(e.pointerId);
    });

    canvas.addEventListener('pointermove', e => {
      if (!drawing) return;
      const rect = canvas.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#f97316';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 3]);
      ctx.fillStyle = 'rgba(249, 115, 22, 0.12)';
      ctx.beginPath();
      ctx.rect(sx, sy, cx - sx, cy - sy);
      ctx.fill();
      ctx.stroke();
    });

    canvas.addEventListener('pointerup', async e => {
      if (!drawing) return;
      drawing = false;
      const rect = canvas.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      /* Calculate natural-pixel rectangle */
      const img = dom.bubbleExpandedImg;
      const scaleX = img.naturalWidth / canvas.width;
      const scaleY = img.naturalHeight / canvas.height;
      const left = Math.min(sx, cx) * scaleX;
      const top  = Math.min(sy, cy) * scaleY;
      const w    = Math.abs(cx - sx) * scaleX;
      const h    = Math.abs(cy - sy) * scaleY;

      if (w < 10 || h < 5) return; // too small

      await performOCR({ left, top, width: w, height: h });
    });
  }

  async function performOCR(rectangle) {
    if (!isOcrReady || !ocrWorker) { toast('OCR not ready.'); return; }
    toast('Recognizing…');
    try {
      const { data: { text } } = await ocrWorker.recognize(dom.bubbleExpandedImg.src, { rectangle });
      const rawText = text.trim();
      if (!rawText) { toast('No text found.'); return; }

      /* ── Block capture mode ── */
      if (blockCaptureMode) {
        deactivateBlockCapture();

        if (blockCaptureForGroup) {
          /* Parse raw OCR into a structured group draft */
          blockCaptureForGroup = false;
          const parsed = parseGroupBlock(rawText);
          fillGroupDraftFromOCR(parsed, rawText);
        } else {
          /* Generic block: show raw text panel for manual copy */
          showOcrPanel(rawText);
          toast('Block captured — ' + rawText.split('\n').length + ' lines.');
        }
        return;
      }

      const cleaned = rawText.replace(/\n/g, ' ');

      if (pickTarget) {
        /* Dynamic target format only when it contains ":" */
        if (pickTarget.includes(':') && pickTarget.startsWith('draft-option-')) {
          const [target, indexStr] = pickTarget.split(':');
          const index = parseInt(indexStr, 10);

          if (!Number.isNaN(index) && groupDraft && groupDraft.options[index]) {
            const field = target.endsWith('name') ? 'name' : 'price';

            if (field === 'name') {
              groupDraft.options[index].name = cleaned;
            } else {
              const m = cleaned.match(/[\d,.]+/);
              groupDraft.options[index].price = m
                ? parseFloat(m[0].replace(/,/g, '.')).toFixed(2)
                : '0.00';
            }

            renderDraftOptionsGrid();
            scheduleAutosave();
            toast('Updated option ' + (index + 1) + ' ' + field + '.');
          }
        } else {
          /* Static target logic */
          const input = $('#' + pickTarget);
          if (input) {
            if (pickTarget.includes('description')) {
              if (input.tagName === 'TEXTAREA') {
                input.value = rawText;
              } else {
                input.value = cleaned;
              }
            } else if (pickTarget.includes('price')) {
              const m = cleaned.match(/[\d,.]+/);
              input.value = m ? parseFloat(m[0].replace(/,/g, '.')).toFixed(2) : '';
            } else {
              input.value = cleaned;
            }

            input.focus();
            input.dispatchEvent(new Event('input', { bubbles: true }));
            toast('Filled: "' + cleaned.substring(0, 40) + (cleaned.length > 40 ? '…' : '') + '"');
          }
        }

        clearPickMode();
        showBubbleMini();
        return;
      }

      /* No active pick target — fill intelligently */
      fillNextField(cleaned);
    } catch (err) {
      console.error('OCR error:', err);
      toast('OCR failed.');
    }
  }

  function fillNextField(text) {
    /* Priority: item name → description → base price → group name → option name → option price */
    if (dom.builderItemName.value.trim() === '') {
      dom.builderItemName.value = text;
      dom.builderItemName.focus();
      toast('Item name: "' + text + '"');
      return;
    }
    if (dom.builderDesc && dom.builderDesc.value.trim() === '') {
      dom.builderDesc.value = text;
      dom.builderDesc.focus();
      toast('Description filled.');
      return;
    }
    if (dom.builderBasePrice.value.trim() === '') {
      const m = text.match(/[\d,.]+/);
      if (m) { dom.builderBasePrice.value = parseFloat(m[0].replace(/,/g, '.')).toFixed(2); }
      else { dom.builderBasePrice.value = text; }
      dom.builderBasePrice.focus();
      toast('Base price filled.');
      return;
    }
    if (groupDraft) {
      if (dom.draftGroupName.value.trim() === '') {
        dom.draftGroupName.value = text;
        toast('Group: "' + text + '"');
        return;
      }
      if (dom.draftOptionName.value.trim() === '') {
        dom.draftOptionName.value = text;
        toast('Option: "' + text + '"');
        return;
      }
      if (dom.draftOptionPrice.value.trim() === '') {
        const m = text.match(/[\d,.]+/);
        if (m) dom.draftOptionPrice.value = parseFloat(m[0].replace(/,/g, '.')).toFixed(2);
        toast('Price filled.');
        return;
      }
      /* All full: start new option */
      dom.draftOptionName.value = text;
      dom.draftOptionPrice.value = '';
      toast('New option: "' + text + '"');
    }
  }

  /* ────────────────────────────────────────────────────────────
     14. PICK MODE (field-driven OCR)
     ──────────────────────────────────────────────────────────── */

  function activatePickMode(targetId) {
    if (!currentImageUrl) { toast('Upload an image first.'); return; }
    pickTarget = targetId;

    /* highlight the active pick button */
    $$('.mc-pick-btn').forEach(b => b.classList.remove('mc-pick-btn--active'));
    const btn = $('[data-pick-target="' + targetId + '"]');
    if (btn) btn.classList.add('mc-pick-btn--active');

    /* build a human-readable hint */
    if (dom.ocrHint) {
      let hintText = 'Draw over the text for: ';

      if (targetId.includes(':')) {
        /* dynamic draft-option target  e.g. draft-option-name:2 */
        const [target, indexStr] = targetId.split(':');
        const field = target.includes('name') ? 'name' : 'price';
        hintText = 'Draw over the ' + field + ' for option ' + (parseInt(indexStr, 10) + 1);
      } else {
        /* static known targets */
        const labels = {
          'builder-name':  'item name',
          'builder-desc':  'description',
          'builder-price': 'price',
          'draft-group-name':  'group name',
          'draft-group-min':   'min selections',
          'draft-group-max':   'max selections'
        };
        hintText += labels[targetId] ||
                    targetId.replace('builder-', '').replace('draft-', '').replace(/-/g, ' ');
      }

      dom.ocrHint.textContent = hintText;
      dom.ocrHint.classList.add('mc-bubble__ocr-hint--active');
    }
    showBubbleExpanded();
  }

  function clearPickMode() {
    pickTarget = null;
    $$('.mc-pick-btn').forEach(b => b.classList.remove('mc-pick-btn--active'));
    if (dom.ocrHint) {
      dom.ocrHint.textContent = 'Draw a rectangle over text to extract it';
      dom.ocrHint.classList.remove('mc-bubble__ocr-hint--active');
    }
  }

  /* ────────────────────────────────────────────────────────────
     14b. BLOCK CAPTURE MODE (capture entire group blocks as text)
     ──────────────────────────────────────────────────────────── */

  function activateBlockCapture() {
    if (!currentImageUrl) { toast('Upload an image first.'); return; }
    clearPickMode();
    blockCaptureMode = true;
    blockCaptureForGroup = false;
    if (dom.btnBlockCapture) dom.btnBlockCapture.classList.add('active');
    if (dom.ocrHint) {
      dom.ocrHint.textContent = 'Draw over an entire group block to capture all text';
      dom.ocrHint.classList.add('mc-bubble__ocr-hint--active');
    }
    showBubbleExpanded();
  }

  /* Triggered by "+ Add Group" when image is loaded */
  function activateBlockCaptureForGroup() {
    clearPickMode();
    blockCaptureMode = true;
    blockCaptureForGroup = true;
    if (dom.btnBlockCapture) dom.btnBlockCapture.classList.add('active');
    if (dom.ocrHint) {
      dom.ocrHint.textContent = '📋 Draw over the full group block (name + all options + prices)';
      dom.ocrHint.classList.add('mc-bubble__ocr-hint--active');
    }
    showBubbleExpanded();
    toast('Select the full group block on the image.');
  }

  function deactivateBlockCapture() {
    blockCaptureMode = false;
    blockCaptureForGroup = false;
    if (dom.btnBlockCapture) dom.btnBlockCapture.classList.remove('active');
    if (dom.ocrHint) {
      dom.ocrHint.textContent = 'Draw a rectangle over text to extract it';
      dom.ocrHint.classList.remove('mc-bubble__ocr-hint--active');
    }
  }

  /* ── Parse raw OCR text block into a structured group object ──
     Handles patterns from real KNX menu modals:
       "Choose Your Size"          → group name
       "1 Required" / "Required"   → required = '1', type = 'single'
       "Tap to remove" / "Remove not add?" → action = 'remove'
       "Half Pan  Tap to select + $74.59"  → option name + price
       "Pickles  Tap to remove"            → remove-action option
  */
  function parseGroupBlock(raw) {
    const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);

    let groupName  = '';
    let required   = '0';
    let type       = 'multiple';
    let action     = 'add';
    const options  = [];

    /* ── Pass 1: detect group-level signals ── */
    for (const line of lines) {
      const lower = line.toLowerCase();

      /* Required badge: "1 Required", "Required", "1 required" */
      if (/\brequired\b/.test(lower)) {
        required = '1';
        /* "1 Required" strongly implies single-select */
        if (/\d\s*required/.test(lower)) type = 'single';
        continue;
      }

      /* Remove-action signals */
      if (/remove not add|tap to remove/i.test(line)) {
        action = 'remove';
        continue;
      }

      /* Skip pure CTA lines (we'll extract prices inline below) */
      if (/^tap to (select|remove)/i.test(line)) continue;
    }

    /* ── Pass 2: extract group name (first meaningful non-CTA line) ── */
    for (const line of lines) {
      const lower = line.toLowerCase();
      if (/\brequired\b/.test(lower)) continue;
      if (/^tap to (select|remove)/i.test(line)) continue;
      if (/remove not add/i.test(line)) continue;
      if (/^\$[\d,.]+$/.test(line)) continue;
      if (line.length < 2) continue;
      groupName = line;
      break;
    }

    /* ── Pass 3: extract option name + price pairs ──
       Two layouts OCR'd from real modals:

       Layout A (name on own line, CTA on next line):
         "Half Pan"
         "Tap to select + $74.59"

       Layout B (merged on one line):
         "Half Pan  Tap to select + $74.59"
         "Half Pan  Tap to select + $0.00"
    */
    const priceRe = /\+\s*\$([\d,.]+)/;
    const ctaRe   = /tap to (select|remove)/i;

    let pendingName = '';

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lower = line.toLowerCase();

      /* Skip group-level lines already processed */
      if (/\brequired\b/.test(lower)) continue;
      if (/remove not add/i.test(lower)) continue;
      if (line === groupName) continue;

      /* Inline merged line: "Name  Tap to select + $X" */
      if (ctaRe.test(line)) {
        const pm = line.match(priceRe);
        const price = pm ? parseFloat(pm[1].replace(/,/g, '')).toFixed(2) : '0.00';

        /* Extract name = everything before "Tap to" */
        const namePart = line.replace(/tap to (select|remove).*$/i, '').trim();
        const optName = namePart || pendingName;
        if (optName) {
          options.push({ name: optName, price, action });
        }
        pendingName = '';
        continue;
      }

      /* Standalone price line "$X.XX" — pair with pending name */
      if (/^\$[\d,.]+$/.test(line)) {
        const price = parseFloat(line.replace(/[$,]/g, '')).toFixed(2);
        if (pendingName) {
          options.push({ name: pendingName, price, action });
          pendingName = '';
        }
        continue;
      }

      /* Looks like an option name — buffer it */
      if (line.length >= 2 && !/^\d+$/.test(line)) {
        if (pendingName) {
          /* Flush pending with $0.00 */
          options.push({ name: pendingName, price: '0.00', action });
        }
        pendingName = line;
      }
    }

    /* Flush last pending */
    if (pendingName) {
      options.push({ name: pendingName, price: '0.00', action });
    }

    return { groupName, required, type, action, options };
  }

  /* Fill the open group draft form with parsed OCR data */
  function fillGroupDraftFromOCR(parsed, rawText) {
    if (!groupDraft) return;

    groupDraft.action   = parsed.action;
    groupDraft.required = parsed.required;
    groupDraft.type     = parsed.type;
    groupDraft.options  = Array.isArray(parsed.options) ? parsed.options : [];

    lastRawOcrText = rawText || '';

    resetChipGroup('action', parsed.action);
    resetChipGroup('required', parsed.required);
    resetChipGroup('type', parsed.type);

    dom.draftGroupName.value = parsed.groupName || '';

    renderDraftOptionsGrid();
    dom.btnCommitGroup.disabled = groupDraft.options.length === 0;

    /* Raw OCR becomes secondary only */
    hideOcrPanel();
    if (dom.btnShowRawOcr) {
      dom.btnShowRawOcr.style.display = lastRawOcrText ? '' : 'none';
    }

    const count = groupDraft.options.length;

    if (count > 0) {
      toast('Group parsed. Review and correct fields if needed.');
    } else {
      toast('Group captured, but options need manual correction.');
      dom.draftGroupName.focus();
    }

    /* Minimize bubble after successful population so the group draft becomes the main focus */
    showBubbleMini();
    scheduleAutosave();
  }

  function showOcrPanel(text) {
    if (dom.ocrPanelText) dom.ocrPanelText.textContent = text;
    if (dom.ocrPanel) dom.ocrPanel.style.display = '';
    syncRawOcrButtonLabel();
  }

  function hideOcrPanel() {
    if (dom.ocrPanel) dom.ocrPanel.style.display = 'none';
    if (dom.ocrPanelText) dom.ocrPanelText.textContent = '';
    syncRawOcrButtonLabel();
  }

  function toggleRawOcrPanel() {
    if (!lastRawOcrText) return;

    if (dom.ocrPanel && dom.ocrPanel.style.display === 'none') {
      showOcrPanel(lastRawOcrText);
    } else {
      hideOcrPanel();
    }
  }

  function syncRawOcrButtonLabel() {
    if (!dom.btnShowRawOcr) return;
    const isOpen = dom.ocrPanel && dom.ocrPanel.style.display !== 'none';
    dom.btnShowRawOcr.textContent = isOpen ? 'Hide Raw OCR' : 'Raw OCR';
  }

  /* ────────────────────────────────────────────────────────────
     15. AUTOSAVE (localStorage)
     ──────────────────────────────────────────────────────────── */

  let autosaveTimer = null;

  function scheduleAutosave() {
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(doAutosave, 800);
  }

  function doAutosave() {
    try {
      const payload = {
        sessionItems,
        categories,
        currentDraft,
        currentImageUrl,
        nextItemId,
        nextGroupId,
        nextOptionId,
        categoryInput: dom.ctxCategory.value,
      };
      localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(payload));
      showAutosaveBadge();
    } catch (e) { /* storage full — ignore */ }
  }

  /* Show "Draft saved" badge briefly */
  let badgeTimer = null;
  function showAutosaveBadge() {
    if (!dom.autosaveBadge) return;
    dom.autosaveBadge.classList.add('visible');
    clearTimeout(badgeTimer);
    badgeTimer = setTimeout(() => dom.autosaveBadge.classList.remove('visible'), 1800);
  }

  function tryRestore() {
    try {
      const raw = localStorage.getItem(AUTOSAVE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);

      if (data.categories && data.categories.length > 0) {
        categories = data.categories;
        updateCatDatalist();
      }
      if (data.categoryInput) {
        dom.ctxCategory.value = data.categoryInput;
      }
      if (data.sessionItems && data.sessionItems.length > 0) {
        sessionItems = data.sessionItems;
        nextItemId = Math.max(nextItemId, ...sessionItems.map(i => i.id)) + 1;
        sessionItems.forEach(item => {
          item.groups.forEach(g => {
            nextGroupId = Math.max(nextGroupId, g.id + 1);
            g.options.forEach(o => { nextOptionId = Math.max(nextOptionId, o.id + 1); });
          });
        });
      }
      if (data.currentDraft) {
        currentDraft = data.currentDraft;
        nextItemId = Math.max(nextItemId, currentDraft.id + 1);
        dom.builderEmpty.style.display = 'none';
        dom.builderContent.style.display = '';
        dom.builderItemName.value = currentDraft.name || '';
        dom.builderBasePrice.value = currentDraft.basePrice || '';
        if (dom.builderDesc) dom.builderDesc.value = currentDraft.description || '';
        renderBuilderGroups();
      }
      if (data.currentImageUrl) {
        currentImageUrl = data.currentImageUrl;
        dom.bubbleMiniImg.src = currentImageUrl;
        dom.bubbleExpandedImg.src = currentImageUrl;
        dom.modalHeroImg.src = currentImageUrl;
        dom.modalHero.style.display = '';
        showBubbleMini();
        initOCR();
      }
      if (data.nextItemId) nextItemId = Math.max(nextItemId, data.nextItemId);
      if (data.nextGroupId) nextGroupId = Math.max(nextGroupId, data.nextGroupId);
      if (data.nextOptionId) nextOptionId = Math.max(nextOptionId, data.nextOptionId);

      return true;
    } catch (e) {
      return false;
    }
  }

  function resetWorkspace() {
    if (sessionItems.length === 0 && !currentDraft) {
      toast('Workspace is already empty.');
      return;
    }
    if (!confirm('Reset entire workspace? This will clear all items, drafts, and local memory.')) return;

    sessionItems = [];
    currentDraft = null;
    groupDraft = null;
    categories = [];
    currentImageUrl = '';
    nextItemId = 1; nextGroupId = 1; nextOptionId = 1;

    dom.ctxCategory.value = '';
    dom.builderEmpty.style.display = '';
    dom.builderContent.style.display = 'none';
    dom.builderItemName.value = '';
    if (dom.builderDesc) dom.builderDesc.value = '';
    dom.builderBasePrice.value = '';
    dom.builderGroups.innerHTML = '';
    dom.modalHero.style.display = 'none';
    closeGroupDraft();
    hideBubble();
    renderSessionList();
    syncAll();
    updateCatDatalist();

    localStorage.removeItem(AUTOSAVE_KEY);
    toast('Workspace reset.');
  }

  /* ────────────────────────────────────────────────────────────
     16. SYNC HELPERS
     ──────────────────────────────────────────────────────────── */

  function syncAddToListBtn() {
    const hasName = (dom.builderItemName.value || '').trim().length > 0;
    const hasCat = getCategory().length > 0;
    dom.btnAddToList.disabled = !(hasName && hasCat && currentDraft);
  }

  function syncAll() {
    const hasItems = sessionItems.length > 0;
    dom.btnExportTop.disabled = !hasItems;
    dom.btnExportBottom.disabled = !hasItems;
    syncAddToListBtn();
    onCategoryChangeUI();
  }

  function onCategoryChangeUI() {
    const hasCategory = getCategory().length > 0;
    dom.btnUploadTop.disabled = !hasCategory;
    dom.btnNewItem.disabled = !hasCategory;
  }

  /* ────────────────────────────────────────────────────────────
     17. TOAST
     ──────────────────────────────────────────────────────────── */

  let toastTimer = null;
  function toast(msg) {
    dom.toast.textContent = msg;
    dom.toast.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => dom.toast.classList.remove('visible'), 2800);
  }

  /* ────────────────────────────────────────────────────────────
     18. UTILITIES
     ──────────────────────────────────────────────────────────── */

  function esc(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }
  function escAttr(s) {
    return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;')
                     .replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* Item validation status for session list */
  function itemStatus(item) {
    if (!item.name) return { label: 'No name', cls: 'warn' };
    if (!item.category) return { label: 'No category', cls: 'warn' };
    if (!item.basePrice || item.basePrice === '0.00') return { label: 'No price', cls: 'warn' };
    if (item.groups.length === 0) return { label: 'No groups', cls: 'info' };
    return { label: 'Complete', cls: 'ok' };
  }

  /* ────────────────────────────────────────────────────────────
     19. INIT
     ──────────────────────────────────────────────────────────── */

  function init() {
    initChips();
    initImageUpload();
    initBubbleDrag();
    initOcrSelection();

    /* Category */
    dom.ctxCategory.addEventListener('input', onCategoryChange);
    dom.ctxCategory.addEventListener('change', onCategoryChange);

    /* Builder item inputs */
    dom.builderItemName.addEventListener('input', () => {
      if (currentDraft) currentDraft.name = dom.builderItemName.value.trim();
      syncAddToListBtn();
      scheduleAutosave();
    });
    dom.builderBasePrice.addEventListener('input', () => {
      if (currentDraft) currentDraft.basePrice = dom.builderBasePrice.value.trim();
      scheduleAutosave();
    });
    if (dom.builderDesc) dom.builderDesc.addEventListener('input', () => {
      if (currentDraft) currentDraft.description = dom.builderDesc.value.trim();
      scheduleAutosave();
    });

    /* Group draft */
    dom.btnAddGroup.addEventListener('click', openGroupDraft);
    dom.btnCancelGroup.addEventListener('click', closeGroupDraft);
    dom.btnQuickFill.addEventListener('click', () => {
      dom.draftOptionPrice.value = '0.00';
      dom.draftOptionName.focus();
    });
    dom.btnAddOption.addEventListener('click', addOptionToDraft);
    dom.draftOptionName.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addOptionToDraft(); } });
    dom.draftOptionPrice.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addOptionToDraft(); } });
    dom.btnCommitGroup.addEventListener('click', commitGroup);

    /* Draft options grid: delete */
    dom.draftOptionsGrid.addEventListener('click', e => {
      const idx = e.target.dataset.removeDraftOpt;
      if (idx !== undefined) removeDraftOption(+idx);
    });

    /* Draft options grid: editable input sync */
    dom.draftOptionsGrid.addEventListener('input', e => {
      const input = e.target.closest('.mc-draft-option-input');
      if (!input || !groupDraft) return;

      const idx = parseInt(input.dataset.draftOptIdx, 10);
      const field = input.dataset.draftOptInput;

      if (Number.isNaN(idx) || !groupDraft.options[idx]) return;

      if (field === 'name') {
        groupDraft.options[idx].name = input.value;
      } else if (field === 'price') {
        groupDraft.options[idx].price = input.value;
      }

      scheduleAutosave();
    });

    /* Raw OCR toggle button */
    if (dom.btnShowRawOcr) {
      dom.btnShowRawOcr.addEventListener('click', toggleRawOcrPanel);
    }

    /* Builder groups: delete */
    dom.builderGroups.addEventListener('click', e => {
      const gid = e.target.dataset.deleteGroup;
      if (gid !== undefined) deleteBuilderGroup(+gid);
    });

    /* Item actions */
    dom.btnAddToList.addEventListener('click', addItemToList);
    dom.btnClearItem.addEventListener('click', clearCurrentItem);
    dom.btnNewItem.addEventListener('click', () => {
      if (currentDraft && (currentDraft.name || currentDraft.groups.length > 0)) {
        if (!confirm('Start a new item? Current unsaved item will be lost.')) return;
      }
      startNewItem();
      toast('New item started.');
    });

    /* Export */
    dom.btnExportTop.addEventListener('click', exportCSV);
    dom.btnExportBottom.addEventListener('click', exportCSV);

    /* Reset workspace */
    dom.btnResetWS.addEventListener('click', resetWorkspace);

    /* Session list events */
    dom.sessionTbody.addEventListener('input', e => {
      if (!e.target.classList.contains('mc-session-table__editable')) return;
      const tr = e.target.closest('tr');
      const item = sessionItems.find(it => it.id === +tr.dataset.sessionItemId);
      if (item) {
        item[e.target.dataset.field] = e.target.value;
        scheduleAutosave();
      }
    });
    dom.sessionTbody.addEventListener('click', e => {
      const eyeId = e.target.dataset.eyeItem;
      if (eyeId !== undefined) openEyePreview(+eyeId);
      const delId = e.target.dataset.deleteItem;
      if (delId !== undefined) deleteSessionItem(+delId);
    });
    dom.sessionSearch.addEventListener('input', renderSessionList);

    /* Bubble controls */
    dom.btnBubbleMinimize.addEventListener('click', showBubbleMini);
    dom.btnBubbleClose.addEventListener('click', showBubbleMini);
    dom.btnBubbleReplace.addEventListener('click', () => dom.imageFileInput.click());

    /* Block capture + OCR panel */
    if (dom.btnBlockCapture) dom.btnBlockCapture.addEventListener('click', () => {
      if (blockCaptureMode) { deactivateBlockCapture(); }
      else { activateBlockCapture(); }
    });
    if (dom.btnOcrPanelClose) dom.btnOcrPanelClose.addEventListener('click', hideOcrPanel);

    /* Eye preview */
    dom.btnEyeClose.addEventListener('click', closeEyePreview);
    const eyeBackdrop = dom.eyeOverlay ? dom.eyeOverlay.querySelector('.mc-eye-overlay__backdrop') : null;
    if (eyeBackdrop) eyeBackdrop.addEventListener('click', closeEyePreview);

    /* Pick buttons (OCR field targeting) */
    document.addEventListener('click', e => {
      const pickBtn = e.target.closest('.mc-pick-btn');
      if (pickBtn && pickBtn.dataset.pickTarget) {
        e.preventDefault();
        activatePickMode(pickBtn.dataset.pickTarget);
      }
    });

    /* Escape key → close overlays */
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (dom.eyeOverlay.style.display !== 'none') { closeEyePreview(); return; }
        if (bubbleState === 'expanded') { showBubbleMini(); return; }
        if (pickTarget) { clearPickMode(); return; }
      }
    });

    /* Protect against accidental tab close */
    window.addEventListener('beforeunload', e => {
      if (sessionItems.length > 0 || (currentDraft && (currentDraft.name || currentDraft.groups.length > 0))) {
        e.preventDefault();
        e.returnValue = '';
      }
    });

    /* Re-sync OCR canvas on window resize */
    window.addEventListener('resize', () => {
      if (bubbleState === 'expanded') syncOcrCanvas();
    });

    /* ── Restore autosave ── */
    const restored = tryRestore();
    if (restored) {
      renderSessionList();
      syncAll();
      toast('Draft restored.');
    } else {
      syncAll();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
