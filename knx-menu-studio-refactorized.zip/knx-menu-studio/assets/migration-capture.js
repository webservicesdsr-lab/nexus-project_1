/* ============================================================
   KNX Menu Studio — Migration Capture
   Visual coordinator · image upload · bubble · drag · boot
   ============================================================ */
(function () {
  'use strict';

  const root = window.KNX_MC;
  if (!root || root.__captureLoaded) return;
  root.__captureLoaded = true;

  const dom = root.dom;
  const state = root.state;
  const toast = root.toast;
  const ajaxUrl = root.ajaxUrl;
  const nonce = root.nonce;
  const scheduleAutosave = root.scheduleAutosave;

  /* ────────────────────────────────────────────────────────────
     1. IMAGE UPLOAD
     ──────────────────────────────────────────────────────────── */

  function initImageUpload() {
    if (!dom.btnUploadTop || !dom.imageFileInput) return;

    dom.btnUploadTop.addEventListener('click', () => {
      dom.imageFileInput.click();
    });

    dom.imageFileInput.addEventListener('change', () => {
      const file = dom.imageFileInput.files[0];
      if (!file) return;

      if (!file.type.startsWith('image/')) {
        toast('Only image files.');
        dom.imageFileInput.value = '';
        return;
      }

      if (file.size > 10 * 1024 * 1024) {
        toast('Max 10 MB.');
        dom.imageFileInput.value = '';
        return;
      }

      if (ajaxUrl && nonce) {
        const fd = new FormData();
        fd.append('image', file);
        fd.append('action', 'knx_studio_upload');
        fd.append('nonce', nonce);

        fetch(ajaxUrl, { method: 'POST', body: fd })
          .then(r => r.ok ? r.json() : Promise.reject(new Error('Upload failed')))
          .then(data => {
            const url = data?.data?.url || data?.url;
            if (data.success && url) {
              setImage(url);
              return;
            }
            throw new Error('Invalid upload response');
          })
          .catch(() => {
            localFallback(file);
          })
          .finally(() => {
            dom.imageFileInput.value = '';
          });
      } else {
        localFallback(file);
        dom.imageFileInput.value = '';
      }
    });
  }

  function localFallback(file) {
    const reader = new FileReader();
    reader.onload = e => {
      setImage(e.target.result);
    };
    reader.readAsDataURL(file);
  }

  function setImage(url) {
    state.currentImageUrl = url;

    if (state.currentDraft) {
      state.currentDraft.imageUrl = url;
    }

    if (dom.bubbleMiniImg) dom.bubbleMiniImg.src = url;
    if (dom.bubbleExpandedImg) dom.bubbleExpandedImg.src = url;
    if (dom.modalHeroImg) dom.modalHeroImg.src = url;
    if (dom.modalHero) dom.modalHero.style.display = '';

    showBubbleExpanded();
    toast('Image loaded.');

    if (typeof root.initOCR === 'function') {
      root.initOCR();
    }

    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     2. BUBBLE VISIBILITY
     ──────────────────────────────────────────────────────────── */

  function showBubbleMini() {
    if (!dom.imgBubble || !dom.bubbleMini || !dom.bubbleExpanded) return;

    state.bubbleState = 'mini';

    dom.imgBubble.style.display = '';
    dom.bubbleMini.style.display = '';
    dom.bubbleExpanded.style.display = 'none';

    dom.imgBubble.style.left = state.bubblePos.x + 'px';
    dom.imgBubble.style.top = state.bubblePos.y + 'px';
  }

  function showBubbleExpanded() {
    if (!dom.imgBubble || !dom.bubbleMini || !dom.bubbleExpanded) return;

    state.bubbleState = 'expanded';

    dom.imgBubble.style.display = '';
    dom.bubbleMini.style.display = 'none';
    dom.bubbleExpanded.style.display = '';

    dom.imgBubble.style.left = '';
    dom.imgBubble.style.top = '';

    if (typeof root.syncOcrCanvas === 'function') {
      root.syncOcrCanvas();
    }
  }

  function hideBubble() {
    if (!dom.imgBubble) return;
    state.bubbleState = 'hidden';
    dom.imgBubble.style.display = 'none';
  }

  /* ────────────────────────────────────────────────────────────
     3. BUBBLE DRAG
     ──────────────────────────────────────────────────────────── */

  function initBubbleDrag() {
    if (!dom.bubbleMini || !dom.imgBubble) return;

    let dragging = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;

    dom.bubbleMini.addEventListener('pointerdown', e => {
      if (state.bubbleState !== 'mini') return;

      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      startLeft = state.bubblePos.x;
      startTop = state.bubblePos.y;

      dom.bubbleMini.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    document.addEventListener('pointermove', e => {
      if (!dragging) return;

      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      state.bubblePos.x = Math.max(0, Math.min(window.innerWidth - 70, startLeft + dx));
      state.bubblePos.y = Math.max(0, Math.min(window.innerHeight - 70, startTop + dy));

      dom.imgBubble.style.left = state.bubblePos.x + 'px';
      dom.imgBubble.style.top = state.bubblePos.y + 'px';
    });

    document.addEventListener('pointerup', e => {
      if (!dragging) return;

      dragging = false;

      const dx = Math.abs(e.clientX - startX);
      const dy = Math.abs(e.clientY - startY);

      if (dx < 6 && dy < 6) {
        showBubbleExpanded();
      } else {
        const midX = window.innerWidth / 2;
        state.bubblePos.x = state.bubblePos.x + 35 < midX ? 12 : window.innerWidth - 76;
        dom.imgBubble.style.left = state.bubblePos.x + 'px';
      }
    });
  }

  /* ────────────────────────────────────────────────────────────
     4. BUBBLE CONTROLS
     ──────────────────────────────────────────────────────────── */

  function initBubbleControls() {
    if (dom.btnBubbleMinimize) {
      dom.btnBubbleMinimize.addEventListener('click', showBubbleMini);
    }

    if (dom.btnBubbleClose) {
      dom.btnBubbleClose.addEventListener('click', showBubbleMini);
    }

    if (dom.btnBubbleReplace && dom.imageFileInput) {
      dom.btnBubbleReplace.addEventListener('click', () => {
        dom.imageFileInput.click();
      });
    }
  }

  /* ────────────────────────────────────────────────────────────
     5. FINAL BOOTSTRAP
     ──────────────────────────────────────────────────────────── */

  function initCaptureCoordinator() {
    initImageUpload();
    initBubbleDrag();
    initBubbleControls();

    if (typeof root.initCore === 'function') {
      root.initCore();
    }

    if (typeof root.initBuilder === 'function') {
      root.initBuilder();
    }

    if (typeof root.initOcrModule === 'function') {
      root.initOcrModule();
    }
  }

  /* ────────────────────────────────────────────────────────────
     6. EXPORT TO SHARED ROOT
     ──────────────────────────────────────────────────────────── */

  root.initImageUpload = initImageUpload;
  root.localFallback = localFallback;
  root.setImage = setImage;

  root.showBubbleMini = showBubbleMini;
  root.showBubbleExpanded = showBubbleExpanded;
  root.hideBubble = hideBubble;

  root.initBubbleDrag = initBubbleDrag;
  root.initBubbleControls = initBubbleControls;
  root.initCaptureCoordinator = initCaptureCoordinator;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCaptureCoordinator, { once: true });
  } else {
    initCaptureCoordinator();
  }
})();