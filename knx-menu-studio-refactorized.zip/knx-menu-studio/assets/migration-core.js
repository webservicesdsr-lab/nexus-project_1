/* ============================================================
   KNX Menu Studio — Migration Core
   Shared state · DOM refs · helpers · category · autosave ·
   session list · CSV · eye preview · base init hooks
   ============================================================ */
(function () {
  'use strict';

  /* Prevent double boot */
  if (window.KNX_MC && window.KNX_MC.__coreLoaded) return;

  /* ────────────────────────────────────────────────────────────
     1. SHARED ROOT
     ──────────────────────────────────────────────────────────── */

  const root = window.KNX_MC || (window.KNX_MC = {});
  root.__coreLoaded = true;

  const $ = s => document.querySelector(s);
  const $$ = s => document.querySelectorAll(s);

  const shell = $('.mc-shell');
  if (!shell) return;

  /* ────────────────────────────────────────────────────────────
     2. DOM REFERENCES
     ──────────────────────────────────────────────────────────── */

  const dom = {
    /* Topbar */
    ctxCategory:      $('#ctx-category'),
    catDatalist:      $('#cat-datalist'),
    btnUploadTop:     $('#btn-upload-top'),
    btnNewItem:       $('#btn-new-item'),
    btnExportTop:     $('#btn-export-top'),
    btnResetWS:       $('#btn-reset-workspace'),
    imageFileInput:   $('#image-file-input'),

    /* Builder */
    builder:          $('#mc-builder'),
    builderEmpty:     $('#builder-empty'),
    builderContent:   $('#builder-content'),
    builderItemName:  $('#builder-item-name'),
    builderBasePrice: $('#builder-base-price'),
    builderDesc:      $('#builder-description'),
    builderGroups:    $('#builder-groups'),
    btnAddGroup:      $('#btn-add-group'),
    btnAddToList:     $('#btn-add-to-list'),
    btnClearItem:     $('#btn-clear-item'),

    /* Modal hero */
    modalHero:        $('#modal-hero'),
    modalHeroImg:     $('#modal-hero-img'),

    /* Group draft */
    groupDraftEl:      $('#group-draft'),
    draftGroupName:    $('#draft-group-name'),
    btnCancelGroup:    $('#btn-cancel-group'),
    btnShowRawOcr:     $('#btn-show-raw-ocr'),
    draftOptionName:   $('#draft-option-name'),
    draftOptionPrice:  $('#draft-option-price'),
    btnQuickFill:      $('#btn-quick-fill'),
    btnAddOption:      $('#btn-add-option'),
    draftOptionsGrid:  $('#draft-options-grid'),
    btnCommitGroup:    $('#btn-commit-group'),

    /* Session list */
    sessionTitle:     $('#session-title'),
    sessionEmpty:     $('#session-empty'),
    sessionTable:     $('#session-table'),
    sessionTbody:     $('#session-tbody'),
    sessionSearch:    $('#session-filter-search'),
    btnExportBottom:  $('#btn-export-bottom'),

    /* Image bubble */
    imgBubble:          $('#img-bubble'),
    bubbleMini:         $('#bubble-mini'),
    bubbleMiniImg:      $('#bubble-mini-img'),
    bubbleExpanded:     $('#bubble-expanded'),
    bubbleExpandedImg:  $('#bubble-expanded-img'),
    bubbleExpandedBody: $('#bubble-expanded-body'),
    ocrCanvas:          $('#ocr-canvas'),
    ocrHint:            $('#ocr-hint'),
    btnBlockCapture:    $('#btn-block-capture'),
    ocrPanel:           $('#ocr-capture-panel'),
    ocrPanelText:       $('#ocr-capture-text'),
    btnOcrPanelClose:   $('#btn-ocr-panel-close'),
    btnBubbleReplace:   $('#btn-bubble-replace'),
    btnBubbleMinimize:  $('#btn-bubble-minimize'),
    btnBubbleClose:     $('#btn-bubble-close'),

    /* Eye preview */
    eyeOverlay:       $('#eye-preview-overlay'),
    eyeBody:          $('#eye-preview-body'),
    btnEyeClose:      $('#btn-eye-close'),

    /* Toast */
    toast:            $('#mc-toast'),
    autosaveBadge:    $('#mc-autosave-badge'),
  };

  const ajaxUrl = shell.dataset.ajaxUrl || '';
  const nonce   = shell.dataset.nonce || '';

  /* ────────────────────────────────────────────────────────────
     3. STATE MODEL
     ──────────────────────────────────────────────────────────── */

  const state = {
    /* Session items */
    sessionItems: [],
    nextItemId: 1,
    nextGroupId: 1,
    nextOptionId: 1,

    /* Drafts */
    currentDraft: null,
    groupDraft: null,

    /* Category memory */
    categories: [],

    /* OCR state */
    pickTarget: null,
    blockCaptureMode: false,
    blockCaptureForGroup: false,
    lastRawOcrText: '',

    /* Image / bubble */
    currentImageUrl: '',
    bubbleState: 'hidden',
    bubblePos: { x: 16, y: 80 },

    /* OCR engine */
    ocrWorker: null,
    isOcrReady: false,

    /* Autosave */
    autosaveTimer: null,
    badgeTimer: null,

    /* Toast */
    toastTimer: null,
  };

  const AUTOSAVE_KEY = 'knx_studio_mc_v2';

  /* ────────────────────────────────────────────────────────────
     4. UTILITIES
     ──────────────────────────────────────────────────────────── */

  function esc(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function escAttr(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function toast(msg) {
    if (!dom.toast) return;
    dom.toast.textContent = msg;
    dom.toast.classList.add('visible');
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => {
      dom.toast.classList.remove('visible');
    }, 2800);
  }

  function showAutosaveBadge() {
    if (!dom.autosaveBadge) return;
    dom.autosaveBadge.classList.add('visible');
    clearTimeout(state.badgeTimer);
    state.badgeTimer = setTimeout(() => {
      dom.autosaveBadge.classList.remove('visible');
    }, 1800);
  }

  function getCategory() {
    return (dom.ctxCategory.value || '').trim();
  }

  function freshItemDraft() {
    return {
      id: state.nextItemId++,
      category: getCategory(),
      name: '',
      description: '',
      basePrice: '',
      groups: [],
      imageUrl: state.currentImageUrl || '',
    };
  }

  function freshGroupDraft() {
    return {
      name: '',
      action: 'add',
      required: '0',
      type: 'multiple',
      options: [],
    };
  }

  function itemStatus(item) {
    if (!item.name) return { label: 'No name', cls: 'warn' };
    if (!item.category) return { label: 'No category', cls: 'warn' };
    if (!item.basePrice || item.basePrice === '0.00') return { label: 'No price', cls: 'warn' };
    if (item.groups.length === 0) return { label: 'No groups', cls: 'info' };
    return { label: 'Complete', cls: 'ok' };
  }

  function csvCell(v) {
    const s = String(v == null ? '' : v);
    return (s.includes(',') || s.includes('"') || s.includes('\n'))
      ? '"' + s.replace(/"/g, '""') + '"'
      : s;
  }

  /* ────────────────────────────────────────────────────────────
     5. CATEGORY MANAGEMENT
     ──────────────────────────────────────────────────────────── */

  function updateCatDatalist() {
    if (!dom.catDatalist) return;
    dom.catDatalist.innerHTML = state.categories.map(c =>
      '<option value="' + escAttr(c) + '">'
    ).join('');
  }

  function onCategoryChangeUI() {
    const hasCategory = getCategory().length > 0;
    if (dom.btnUploadTop) dom.btnUploadTop.disabled = !hasCategory;
    if (dom.btnNewItem) dom.btnNewItem.disabled = !hasCategory;
  }

  function onCategoryChange() {
    const cat = getCategory();
    const hasCategory = cat.length > 0;

    if (hasCategory && !state.categories.includes(cat)) {
      state.categories.push(cat);
      updateCatDatalist();
    }

    if (dom.btnUploadTop) dom.btnUploadTop.disabled = !hasCategory;
    if (dom.btnNewItem) dom.btnNewItem.disabled = !hasCategory;

    if (hasCategory && !state.currentDraft && typeof root.startNewItem === 'function') {
      root.startNewItem();
    }

    if (state.currentDraft) {
      state.currentDraft.category = cat;
    }

    syncAll();
    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     6. SESSION LIST
     ──────────────────────────────────────────────────────────── */

  function renderSessionList() {
    if (!dom.sessionTitle || !dom.sessionEmpty || !dom.sessionTable || !dom.sessionTbody) return;

    const search = (dom.sessionSearch.value || '').trim().toLowerCase();

    const filtered = search
      ? state.sessionItems.filter(it =>
          (it.name || '').toLowerCase().includes(search) ||
          (it.category || '').toLowerCase().includes(search)
        )
      : state.sessionItems;

    dom.sessionTitle.textContent =
      'Session — ' + state.sessionItems.length + ' item' + (state.sessionItems.length !== 1 ? 's' : '');

    if (filtered.length === 0) {
      dom.sessionEmpty.style.display = '';
      dom.sessionTable.style.display = 'none';
      return;
    }

    dom.sessionEmpty.style.display = 'none';
    dom.sessionTable.style.display = '';

    dom.sessionTbody.innerHTML = filtered.map(it => {
      const optCount = it.groups.reduce((sum, g) => sum + g.options.length, 0);
      const groupsText = it.groups.length + ' group' + (it.groups.length !== 1 ? 's' : '') + ' · ' + optCount + ' opt';
      const status = itemStatus(it);

      return '<tr data-session-item-id="' + it.id + '">'
        + '<td><input class="mc-session-table__editable" data-field="category" value="' + escAttr(it.category) + '"></td>'
        + '<td><input class="mc-session-table__editable" data-field="name" value="' + escAttr(it.name) + '"></td>'
        + '<td><input class="mc-session-table__editable mc-session-table__editable--desc" data-field="description" value="' + escAttr(it.description || '') + '" placeholder="—"></td>'
        + '<td><input class="mc-session-table__editable" data-field="basePrice" value="' + escAttr(it.basePrice) + '" style="width:70px;" inputmode="decimal"></td>'
        + '<td><span class="mc-session-table__groups-count">' + groupsText + '</span></td>'
        + '<td><span class="mc-session-table__status mc-session-table__status--' + status.cls + '">' + status.label + '</span></td>'
        + '<td><div class="mc-session-table__action-btns">'
        + '<button class="mc-session-table__eye" data-eye-item="' + it.id + '" title="Preview">👁</button>'
        + '<button class="mc-session-table__delete" data-delete-item="' + it.id + '" title="Delete">×</button>'
        + '</div></td>'
        + '</tr>';
    }).join('');
  }

  function deleteSessionItem(id) {
    state.sessionItems = state.sessionItems.filter(it => it.id !== id);
    renderSessionList();
    syncAll();
    scheduleAutosave();
    toast('Item removed from session.');
  }

  /* ────────────────────────────────────────────────────────────
     7. EYE PREVIEW
     ──────────────────────────────────────────────────────────── */

  function openEyePreview(itemId) {
    const item = state.sessionItems.find(it => it.id === itemId);
    if (!item || !dom.eyeBody || !dom.eyeOverlay) return;

    let html = '<div class="mc-modal-dialog">';

    html += '<div class="mc-modal-header-card">';
    html += '<div class="mc-modal-header-card__row"><input class="mc-modal-title-input" value="' + escAttr(item.name) + '" readonly></div>';
    if (item.description) {
      html += '<div class="mc-modal-desc-row"><textarea class="mc-modal-desc-input" readonly>' + esc(item.description) + '</textarea></div>';
    }
    html += '<div class="mc-modal-price-row"><span class="mc-modal-price-label">$</span><input class="mc-modal-price-input" value="' + escAttr(item.basePrice) + '" readonly></div>';
    html += '</div>';

    item.groups.forEach(g => {
      const reqBadge = g.required === '1'
        ? '<span class="mc-modal-group-badge mc-modal-group-badge--required">Required</span>'
        : '<span class="mc-modal-group-badge mc-modal-group-badge--type">Optional</span>';

      const typeBadge = '<span class="mc-modal-group-badge mc-modal-group-badge--type">' + esc(g.type) + '</span>';

      html += '<section class="mc-modal-group"><div class="mc-modal-group-header">';
      html += '<h3 class="mc-modal-group-title">' + esc(g.name) + '</h3>';
      html += '<div class="mc-modal-group-meta">' + reqBadge + typeBadge + '</div></div>';
      html += '<div class="mc-modal-options">';

      g.options.forEach(opt => {
        const isRemove = opt.action === 'remove';
        const removeCls = isRemove ? ' mc-modal-option--remove' : '';
        const ctaText = isRemove ? 'Exclude' : 'Add';
        const priceText = parseFloat(opt.price) > 0 ? ' $' + opt.price : '';

        html += '<div class="mc-modal-option' + removeCls + '">';
        html += '<span class="mc-modal-option-label">' + esc(opt.name) + '</span>';
        html += '<span class="mc-modal-option-cta">' + ctaText + '<strong class="mc-modal-option-cta-price">' + priceText + '</strong></span>';
        html += '</div>';
      });

      html += '</div></section>';
    });

    html += '</div>';

    dom.eyeBody.innerHTML = html;
    dom.eyeOverlay.style.display = '';
  }

  function closeEyePreview() {
    if (!dom.eyeOverlay || !dom.eyeBody) return;
    dom.eyeOverlay.style.display = 'none';
    dom.eyeBody.innerHTML = '';
  }

  /* ────────────────────────────────────────────────────────────
     8. CSV EXPORT
     ──────────────────────────────────────────────────────────── */

  const CSV_COLS = [
    'category_name',
    'item_name',
    'item_description',
    'group_name',
    'group_required',
    'group_type',
    'option_name',
    'option_price',
    'option_action'
  ];

  function exportCSV() {
    if (state.sessionItems.length === 0) {
      toast('No items to export.');
      return;
    }

    const rows = [];

    state.sessionItems.forEach(item => {
      if (item.groups.length === 0) {
        rows.push({
          category_name: item.category,
          item_name: item.name,
          item_description: item.description || '',
          group_name: '',
          group_required: '',
          group_type: '',
          option_name: '',
          option_price: item.basePrice,
          option_action: '',
        });
      } else {
        item.groups.forEach(group => {
          group.options.forEach(opt => {
            rows.push({
              category_name: item.category,
              item_name: item.name,
              item_description: item.description || '',
              group_name: group.name,
              group_required: group.required,
              group_type: group.type,
              option_name: opt.name,
              option_price: opt.price,
              option_action: opt.action,
            });
          });
        });
      }
    });

    if (rows.length === 0) {
      toast('Nothing to export.');
      return;
    }

    const header = CSV_COLS.join(',');
    const body = rows.map(r => CSV_COLS.map(c => csvCell(r[c])).join(',')).join('\n');
    const csv = header + '\n' + body + '\n';

    const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = 'migration-' + slug(getCategory() || 'export') + '-' + dateStr + '.csv';

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');

    a.href = url;
    a.download = filename;
    a.style.display = 'none';

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast('Exported ' + rows.length + ' rows → ' + filename);
  }

  /* ────────────────────────────────────────────────────────────
     9. AUTOSAVE
     ──────────────────────────────────────────────────────────── */

  function scheduleAutosave() {
    clearTimeout(state.autosaveTimer);
    state.autosaveTimer = setTimeout(doAutosave, 800);
  }

  function doAutosave() {
    try {
      const payload = {
        sessionItems: state.sessionItems,
        categories: state.categories,
        currentDraft: state.currentDraft,
        currentImageUrl: state.currentImageUrl,
        nextItemId: state.nextItemId,
        nextGroupId: state.nextGroupId,
        nextOptionId: state.nextOptionId,
        categoryInput: dom.ctxCategory ? dom.ctxCategory.value : '',
      };

      localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(payload));
      showAutosaveBadge();
    } catch (e) {
      /* storage full — ignore */
    }
  }

  function tryRestore() {
    try {
      const raw = localStorage.getItem(AUTOSAVE_KEY);
      if (!raw) return false;

      const data = JSON.parse(raw);

      if (data.categories && data.categories.length > 0) {
        state.categories = data.categories;
        updateCatDatalist();
      }

      if (data.categoryInput && dom.ctxCategory) {
        dom.ctxCategory.value = data.categoryInput;
      }

      if (data.sessionItems && data.sessionItems.length > 0) {
        state.sessionItems = data.sessionItems;
        state.nextItemId = Math.max(state.nextItemId, ...state.sessionItems.map(i => i.id)) + 1;

        state.sessionItems.forEach(item => {
          item.groups.forEach(g => {
            state.nextGroupId = Math.max(state.nextGroupId, g.id + 1);
            g.options.forEach(o => {
              state.nextOptionId = Math.max(state.nextOptionId, o.id + 1);
            });
          });
        });
      }

      if (data.currentDraft) {
        state.currentDraft = data.currentDraft;
        state.nextItemId = Math.max(state.nextItemId, state.currentDraft.id + 1);

        if (dom.builderEmpty) dom.builderEmpty.style.display = 'none';
        if (dom.builderContent) dom.builderContent.style.display = '';
        if (dom.builderItemName) dom.builderItemName.value = state.currentDraft.name || '';
        if (dom.builderBasePrice) dom.builderBasePrice.value = state.currentDraft.basePrice || '';
        if (dom.builderDesc) dom.builderDesc.value = state.currentDraft.description || '';

        if (typeof root.renderBuilderGroups === 'function') {
          root.renderBuilderGroups();
        }
      }

      if (data.currentImageUrl) {
        state.currentImageUrl = data.currentImageUrl;

        if (dom.bubbleMiniImg) dom.bubbleMiniImg.src = state.currentImageUrl;
        if (dom.bubbleExpandedImg) dom.bubbleExpandedImg.src = state.currentImageUrl;
        if (dom.modalHeroImg) dom.modalHeroImg.src = state.currentImageUrl;
        if (dom.modalHero) dom.modalHero.style.display = '';

        if (typeof root.showBubbleMini === 'function') {
          root.showBubbleMini();
        }

        if (typeof root.initOCR === 'function') {
          root.initOCR();
        }
      }

      if (data.nextItemId) state.nextItemId = Math.max(state.nextItemId, data.nextItemId);
      if (data.nextGroupId) state.nextGroupId = Math.max(state.nextGroupId, data.nextGroupId);
      if (data.nextOptionId) state.nextOptionId = Math.max(state.nextOptionId, data.nextOptionId);

      return true;
    } catch (e) {
      return false;
    }
  }

  function resetWorkspace() {
    if (state.sessionItems.length === 0 && !state.currentDraft) {
      toast('Workspace is already empty.');
      return;
    }

    if (!confirm('Reset entire workspace? This will clear all items, drafts, and local memory.')) {
      return;
    }

    state.sessionItems = [];
    state.currentDraft = null;
    state.groupDraft = null;
    state.categories = [];
    state.currentImageUrl = '';
    state.nextItemId = 1;
    state.nextGroupId = 1;
    state.nextOptionId = 1;
    state.pickTarget = null;
    state.blockCaptureMode = false;
    state.blockCaptureForGroup = false;
    state.lastRawOcrText = '';

    if (dom.ctxCategory) dom.ctxCategory.value = '';
    if (dom.builderEmpty) dom.builderEmpty.style.display = '';
    if (dom.builderContent) dom.builderContent.style.display = 'none';
    if (dom.builderItemName) dom.builderItemName.value = '';
    if (dom.builderDesc) dom.builderDesc.value = '';
    if (dom.builderBasePrice) dom.builderBasePrice.value = '';
    if (dom.builderGroups) dom.builderGroups.innerHTML = '';
    if (dom.modalHero) dom.modalHero.style.display = 'none';

    if (typeof root.closeGroupDraft === 'function') root.closeGroupDraft();
    if (typeof root.hideBubble === 'function') root.hideBubble();

    renderSessionList();
    syncAll();
    updateCatDatalist();

    localStorage.removeItem(AUTOSAVE_KEY);
    toast('Workspace reset.');
  }

  /* ────────────────────────────────────────────────────────────
     10. SYNC HELPERS
     ──────────────────────────────────────────────────────────── */

  function syncAddToListBtn() {
    const hasName = (dom.builderItemName && dom.builderItemName.value || '').trim().length > 0;
    const hasCat = getCategory().length > 0;
    if (dom.btnAddToList) {
      dom.btnAddToList.disabled = !(hasName && hasCat && state.currentDraft);
    }
  }

  function syncAll() {
    const hasItems = state.sessionItems.length > 0;
    if (dom.btnExportTop) dom.btnExportTop.disabled = !hasItems;
    if (dom.btnExportBottom) dom.btnExportBottom.disabled = !hasItems;
    syncAddToListBtn();
    onCategoryChangeUI();
  }

  /* ────────────────────────────────────────────────────────────
     11. BASE INIT
     ──────────────────────────────────────────────────────────── */

  function initCore() {
    if (dom.ctxCategory) {
      dom.ctxCategory.addEventListener('input', onCategoryChange);
      dom.ctxCategory.addEventListener('change', onCategoryChange);
    }

    if (dom.btnExportTop) dom.btnExportTop.addEventListener('click', exportCSV);
    if (dom.btnExportBottom) dom.btnExportBottom.addEventListener('click', exportCSV);
    if (dom.btnResetWS) dom.btnResetWS.addEventListener('click', resetWorkspace);

    if (dom.sessionTbody) {
      dom.sessionTbody.addEventListener('input', e => {
        if (!e.target.classList.contains('mc-session-table__editable')) return;

        const tr = e.target.closest('tr');
        const item = state.sessionItems.find(it => it.id === +tr.dataset.sessionItemId);

        if (item) {
          item[e.target.dataset.field] = e.target.value;
          scheduleAutosave();
        }
      });

      dom.sessionTbody.addEventListener('click', e => {
        const eyeId = e.target.dataset.eyeItem;
        if (eyeId !== undefined) openEyePreview(+eyeId);

        const delId = e.target.dataset.deleteItem;
        if (delId !== undefined) deleteSessionItem(+delId);
      });
    }

    if (dom.sessionSearch) {
      dom.sessionSearch.addEventListener('input', renderSessionList);
    }

    if (dom.btnEyeClose) {
      dom.btnEyeClose.addEventListener('click', closeEyePreview);
    }

    const eyeBackdrop = dom.eyeOverlay
      ? dom.eyeOverlay.querySelector('.mc-eye-overlay__backdrop')
      : null;

    if (eyeBackdrop) {
      eyeBackdrop.addEventListener('click', closeEyePreview);
    }

    window.addEventListener('beforeunload', e => {
      if (
        state.sessionItems.length > 0 ||
        (state.currentDraft && (state.currentDraft.name || state.currentDraft.groups.length > 0))
      ) {
        e.preventDefault();
        e.returnValue = '';
      }
    });

    const restored = tryRestore();
    if (restored) {
      renderSessionList();
      syncAll();
      toast('Draft restored.');
    } else {
      syncAll();
    }
  }

  /* ────────────────────────────────────────────────────────────
     12. EXPORT TO SHARED ROOT
     ──────────────────────────────────────────────────────────── */

  root.$ = $;
  root.$$ = $$;
  root.dom = dom;
  root.state = state;
  root.ajaxUrl = ajaxUrl;
  root.nonce = nonce;
  root.AUTOSAVE_KEY = AUTOSAVE_KEY;

  root.esc = esc;
  root.escAttr = escAttr;
  root.toast = toast;
  root.showAutosaveBadge = showAutosaveBadge;
  root.scheduleAutosave = scheduleAutosave;
  root.doAutosave = doAutosave;

  root.getCategory = getCategory;
  root.updateCatDatalist = updateCatDatalist;
  root.onCategoryChange = onCategoryChange;
  root.onCategoryChangeUI = onCategoryChangeUI;

  root.freshItemDraft = freshItemDraft;
  root.freshGroupDraft = freshGroupDraft;
  root.itemStatus = itemStatus;

  root.renderSessionList = renderSessionList;
  root.deleteSessionItem = deleteSessionItem;
  root.openEyePreview = openEyePreview;
  root.closeEyePreview = closeEyePreview;

  root.csvCell = csvCell;
  root.exportCSV = exportCSV;

  root.tryRestore = tryRestore;
  root.resetWorkspace = resetWorkspace;

  root.syncAddToListBtn = syncAddToListBtn;
  root.syncAll = syncAll;

  root.initCore = initCore;

  /* Optional boot if loaded standalone first */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCore, { once: true });
  } else {
    initCore();
  }
})();