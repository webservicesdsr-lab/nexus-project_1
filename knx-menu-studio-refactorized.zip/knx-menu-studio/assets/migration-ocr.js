/* ============================================================
   KNX Menu Studio — Migration OCR
   OCR engine · selection · pick mode · block capture · parser
   ============================================================ */
(function () {
  'use strict';

  const root = window.KNX_MC;
  if (!root || root.__ocrLoaded) return;
  root.__ocrLoaded = true;

  const dom = root.dom;
  const state = root.state;
  const toast = root.toast;
  const scheduleAutosave = root.scheduleAutosave;
  const $ = root.$;
  const $$ = root.$$;

  /* ────────────────────────────────────────────────────────────
     1. OCR ENGINE
     ──────────────────────────────────────────────────────────── */

  async function initOCR() {
    if (state.ocrWorker || !window.Tesseract) return;

    try {
      toast('Loading OCR engine…');

      state.ocrWorker = await Tesseract.createWorker('eng', 1, {
        logger: m => {
          if (m.status === 'recognizing text') {
            toast('Recognizing… ' + (m.progress * 100).toFixed(0) + '%');
          }
        }
      });

      state.isOcrReady = true;
      toast('OCR ready. Draw on image to extract text.');
    } catch (err) {
      console.error('OCR init failed:', err);
      toast('OCR unavailable.');
    }
  }

  function syncOcrCanvas() {
    const img = dom.bubbleExpandedImg;
    const body = dom.bubbleExpandedBody;

    if (!img || !body || !dom.ocrCanvas) return;

    if (!img.naturalWidth) {
      img.onload = () => syncOcrCanvas();
      return;
    }

    dom.ocrCanvas.width = body.clientWidth;
    dom.ocrCanvas.height = body.clientHeight;
  }

  function initOcrSelection() {
    if (!dom.ocrCanvas) return;

    const canvas = dom.ocrCanvas;
    const ctx = canvas.getContext('2d');
    let drawing = false;
    let sx = 0;
    let sy = 0;

    canvas.addEventListener('pointerdown', e => {
      drawing = true;
      const rect = canvas.getBoundingClientRect();
      sx = e.clientX - rect.left;
      sy = e.clientY - rect.top;
      canvas.setPointerCapture(e.pointerId);
    });

    canvas.addEventListener('pointermove', e => {
      if (!drawing) return;

      const rect = canvas.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#f97316';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 3]);
      ctx.fillStyle = 'rgba(249, 115, 22, 0.12)';
      ctx.beginPath();
      ctx.rect(sx, sy, cx - sx, cy - sy);
      ctx.fill();
      ctx.stroke();
    });

    canvas.addEventListener('pointerup', async e => {
      if (!drawing) return;
      drawing = false;

      const rect = canvas.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const img = dom.bubbleExpandedImg;
      if (!img) return;

      const scaleX = img.naturalWidth / canvas.width;
      const scaleY = img.naturalHeight / canvas.height;
      const left = Math.min(sx, cx) * scaleX;
      const top = Math.min(sy, cy) * scaleY;
      const w = Math.abs(cx - sx) * scaleX;
      const h = Math.abs(cy - sy) * scaleY;

      if (w < 10 || h < 5) return;

      await performOCR({ left, top, width: w, height: h });
    });
  }

  /* ────────────────────────────────────────────────────────────
     2. OCR ROUTER
     ──────────────────────────────────────────────────────────── */

  async function performOCR(rectangle) {
    if (!state.isOcrReady || !state.ocrWorker) {
      toast('OCR not ready.');
      return;
    }

    toast('Recognizing…');

    try {
      const { data: { text } } = await state.ocrWorker.recognize(dom.bubbleExpandedImg.src, { rectangle });
      const rawText = text.trim();

      if (!rawText) {
        toast('No text found.');
        return;
      }

      /* Block capture mode */
      if (state.blockCaptureMode) {
        const wasGroupCapture = state.blockCaptureForGroup;
        deactivateBlockCapture();

        if (wasGroupCapture) {
          const parsed = parseGroupBlock(rawText);
          fillGroupDraftFromOCR(parsed, rawText);
        } else {
          showOcrPanel(rawText);
          toast('Block captured — ' + rawText.split('\n').length + ' lines.');
        }

        return;
      }

      const cleaned = rawText.replace(/\n/g, ' ');

      if (state.pickTarget) {
        if (state.pickTarget.includes(':') && state.pickTarget.startsWith('draft-option-')) {
          const [target, indexStr] = state.pickTarget.split(':');
          const index = parseInt(indexStr, 10);

          if (!Number.isNaN(index) && state.groupDraft && state.groupDraft.options[index]) {
            const field = target.endsWith('name') ? 'name' : 'price';

            if (field === 'name') {
              state.groupDraft.options[index].name = cleaned;
            } else {
              const m = cleaned.match(/[\d,.]+/);
              state.groupDraft.options[index].price = m
                ? parseFloat(m[0].replace(/,/g, '.')).toFixed(2)
                : '0.00';
            }

            if (typeof root.renderDraftOptionsGrid === 'function') {
              root.renderDraftOptionsGrid();
            }

            scheduleAutosave();
            toast('Updated option ' + (index + 1) + ' ' + field + '.');
          }
        } else {
          const input = $('#' + state.pickTarget);

          if (input) {
            if (state.pickTarget.includes('description')) {
              if (input.tagName === 'TEXTAREA') {
                input.value = rawText;
              } else {
                input.value = cleaned;
              }
            } else if (state.pickTarget.includes('price')) {
              const m = cleaned.match(/[\d,.]+/);
              input.value = m ? parseFloat(m[0].replace(/,/g, '.')).toFixed(2) : '';
            } else {
              input.value = cleaned;
            }

            input.focus();
            input.dispatchEvent(new Event('input', { bubbles: true }));
            toast('Filled: "' + cleaned.substring(0, 40) + (cleaned.length > 40 ? '…' : '') + '"');
          }
        }

        clearPickMode();
        if (typeof root.showBubbleMini === 'function') {
          root.showBubbleMini();
        }
        return;
      }

      fillNextField(cleaned);
    } catch (err) {
      console.error('OCR error:', err);
      toast('OCR failed.');
    }
  }

  function fillNextField(text) {
    if (dom.builderItemName && dom.builderItemName.value.trim() === '') {
      dom.builderItemName.value = text;
      dom.builderItemName.focus();
      toast('Item name: "' + text + '"');
      return;
    }

    if (dom.builderDesc && dom.builderDesc.value.trim() === '') {
      dom.builderDesc.value = text;
      dom.builderDesc.focus();
      toast('Description filled.');
      return;
    }

    if (dom.builderBasePrice && dom.builderBasePrice.value.trim() === '') {
      const m = text.match(/[\d,.]+/);
      dom.builderBasePrice.value = m
        ? parseFloat(m[0].replace(/,/g, '.')).toFixed(2)
        : text;
      dom.builderBasePrice.focus();
      toast('Base price filled.');
      return;
    }

    if (state.groupDraft) {
      if (dom.draftGroupName && dom.draftGroupName.value.trim() === '') {
        dom.draftGroupName.value = text;
        toast('Group: "' + text + '"');
        return;
      }

      if (dom.draftOptionName && dom.draftOptionName.value.trim() === '') {
        dom.draftOptionName.value = text;
        toast('Option: "' + text + '"');
        return;
      }

      if (dom.draftOptionPrice && dom.draftOptionPrice.value.trim() === '') {
        const m = text.match(/[\d,.]+/);
        if (m) dom.draftOptionPrice.value = parseFloat(m[0].replace(/,/g, '.')).toFixed(2);
        toast('Price filled.');
        return;
      }

      if (dom.draftOptionName) dom.draftOptionName.value = text;
      if (dom.draftOptionPrice) dom.draftOptionPrice.value = '';
      toast('New option: "' + text + '"');
    }
  }

  /* ────────────────────────────────────────────────────────────
     3. PICK MODE
     ──────────────────────────────────────────────────────────── */

  function activatePickMode(targetId) {
    if (!state.currentImageUrl) {
      toast('Upload an image first.');
      return;
    }

    state.pickTarget = targetId;

    $$('.mc-pick-btn').forEach(b => b.classList.remove('mc-pick-btn--active'));

    const btn = $('[data-pick-target="' + targetId + '"]');
    if (btn) btn.classList.add('mc-pick-btn--active');

    if (dom.ocrHint) {
      let hintText = 'Draw over the text to fill this field';

      if (targetId.includes(':') && targetId.startsWith('draft-option-')) {
        const [target, indexStr] = targetId.split(':');
        const field = target.endsWith('name') ? 'name' : 'price';
        const n = parseInt(indexStr, 10);
        hintText = 'Draw over the ' + field + ' for option ' + (n + 1);
      } else if (targetId === 'builder-item-name') {
        hintText = 'Draw over the item name';
      } else if (targetId === 'builder-base-price') {
        hintText = 'Draw over the base price';
      } else if (targetId === 'builder-description') {
        hintText = 'Draw over the description';
      } else if (targetId === 'draft-group-name') {
        hintText = 'Draw over the group title';
      } else if (targetId === 'draft-option-name') {
        hintText = 'Draw over the option name';
      } else if (targetId === 'draft-option-price') {
        hintText = 'Draw over the option price';
      }

      dom.ocrHint.textContent = hintText;
      dom.ocrHint.classList.add('mc-bubble__ocr-hint--active');
    }

    if (typeof root.showBubbleExpanded === 'function') {
      root.showBubbleExpanded();
    }
  }

  function clearPickMode() {
    state.pickTarget = null;
    $$('.mc-pick-btn').forEach(b => b.classList.remove('mc-pick-btn--active'));

    if (dom.ocrHint) {
      dom.ocrHint.textContent = 'Draw a rectangle over text to extract it';
      dom.ocrHint.classList.remove('mc-bubble__ocr-hint--active');
    }
  }

  /* ────────────────────────────────────────────────────────────
     4. BLOCK CAPTURE MODE
     ──────────────────────────────────────────────────────────── */

  function activateBlockCapture() {
    if (!state.currentImageUrl) {
      toast('Upload an image first.');
      return;
    }

    clearPickMode();
    state.blockCaptureMode = true;
    state.blockCaptureForGroup = false;

    if (dom.btnBlockCapture) dom.btnBlockCapture.classList.add('active');

    if (dom.ocrHint) {
      dom.ocrHint.textContent = 'Draw over an entire group block to capture all text';
      dom.ocrHint.classList.add('mc-bubble__ocr-hint--active');
    }

    if (typeof root.showBubbleExpanded === 'function') {
      root.showBubbleExpanded();
    }
  }

  function activateBlockCaptureForGroup() {
    clearPickMode();
    state.blockCaptureMode = true;
    state.blockCaptureForGroup = true;

    if (dom.btnBlockCapture) dom.btnBlockCapture.classList.add('active');

    if (dom.ocrHint) {
      dom.ocrHint.textContent = '📋 Draw over the full group block (name + all options + prices)';
      dom.ocrHint.classList.add('mc-bubble__ocr-hint--active');
    }

    if (typeof root.showBubbleExpanded === 'function') {
      root.showBubbleExpanded();
    }

    toast('Select the full group block on the image.');
  }

  function deactivateBlockCapture() {
    state.blockCaptureMode = false;
    state.blockCaptureForGroup = false;

    if (dom.btnBlockCapture) dom.btnBlockCapture.classList.remove('active');

    if (dom.ocrHint) {
      dom.ocrHint.textContent = 'Draw a rectangle over text to extract it';
      dom.ocrHint.classList.remove('mc-bubble__ocr-hint--active');
    }
  }

  /* ────────────────────────────────────────────────────────────
     5. GROUP BLOCK PARSER
     ──────────────────────────────────────────────────────────── */

  function parseGroupBlock(raw) {
    const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);

    let groupName = '';
    let required = '0';
    let type = 'multiple';
    let action = 'add';
    const options = [];

    for (const line of lines) {
      const lower = line.toLowerCase();

      if (/\brequired\b/.test(lower)) {
        required = '1';
        if (/\d\s*required/.test(lower)) type = 'single';
        continue;
      }

      if (/remove not add|tap to remove/i.test(line)) {
        action = 'remove';
        continue;
      }

      if (/^tap to (select|remove)/i.test(line)) continue;
    }

    for (const line of lines) {
      const lower = line.toLowerCase();
      if (/\brequired\b/.test(lower)) continue;
      if (/^tap to (select|remove)/i.test(line)) continue;
      if (/remove not add/i.test(line)) continue;
      if (/^\$[\d,.]+$/.test(line)) continue;
      if (line.length < 2) continue;
      groupName = line;
      break;
    }

    const priceRe = /\+\s*\$([\d,.]+)/;
    const ctaRe = /tap to (select|remove)/i;

    let pendingName = '';

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lower = line.toLowerCase();

      if (/\brequired\b/.test(lower)) continue;
      if (/remove not add/i.test(lower)) continue;
      if (line === groupName) continue;

      if (ctaRe.test(line)) {
        const pm = line.match(priceRe);
        const price = pm ? parseFloat(pm[1].replace(/,/g, '')).toFixed(2) : '0.00';
        const namePart = line.replace(/tap to (select|remove).*$/i, '').trim();
        const optName = namePart || pendingName;

        if (optName) {
          options.push({ name: optName, price, action });
        }

        pendingName = '';
        continue;
      }

      if (/^\$[\d,.]+$/.test(line)) {
        const price = parseFloat(line.replace(/[$,]/g, '')).toFixed(2);
        if (pendingName) {
          options.push({ name: pendingName, price, action });
          pendingName = '';
        }
        continue;
      }

      if (line.length >= 2 && !/^\d+$/.test(line)) {
        if (pendingName) {
          options.push({ name: pendingName, price: '0.00', action });
        }
        pendingName = line;
      }
    }

    if (pendingName) {
      options.push({ name: pendingName, price: '0.00', action });
    }

    return { groupName, required, type, action, options };
  }

  function fillGroupDraftFromOCR(parsed, rawText) {
    if (!state.groupDraft) return;

    state.groupDraft.action = parsed.action;
    state.groupDraft.required = parsed.required;
    state.groupDraft.type = parsed.type;
    state.groupDraft.options = Array.isArray(parsed.options) ? parsed.options : [];

    state.lastRawOcrText = rawText || '';

    if (typeof root.resetChipGroup === 'function') {
      root.resetChipGroup('action', parsed.action);
      root.resetChipGroup('required', parsed.required);
      root.resetChipGroup('type', parsed.type);
    }

    if (dom.draftGroupName) dom.draftGroupName.value = parsed.groupName || '';

    if (typeof root.renderDraftOptionsGrid === 'function') {
      root.renderDraftOptionsGrid();
    }

    if (dom.btnCommitGroup) {
      dom.btnCommitGroup.disabled = state.groupDraft.options.length === 0;
    }

    hideOcrPanel();

    if (dom.btnShowRawOcr) {
      dom.btnShowRawOcr.style.display = state.lastRawOcrText ? '' : 'none';
    }

    const count = state.groupDraft.options.length;

    if (count > 0) {
      toast('Group parsed. Review and correct fields if needed.');
    } else {
      toast('Group captured, but options need manual correction.');
      if (dom.draftGroupName) dom.draftGroupName.focus();
    }

    if (typeof root.showBubbleMini === 'function') {
      root.showBubbleMini();
    }

    scheduleAutosave();
  }

  /* ────────────────────────────────────────────────────────────
     6. RAW OCR PANEL
     ──────────────────────────────────────────────────────────── */

  function showOcrPanel(text) {
    if (dom.ocrPanelText) dom.ocrPanelText.textContent = text;
    if (dom.ocrPanel) dom.ocrPanel.style.display = '';
    syncRawOcrButtonLabel();
  }

  function hideOcrPanel() {
    if (dom.ocrPanel) dom.ocrPanel.style.display = 'none';
    if (dom.ocrPanelText) dom.ocrPanelText.textContent = '';
    syncRawOcrButtonLabel();
  }

  function toggleRawOcrPanel() {
    if (!state.lastRawOcrText) return;

    if (dom.ocrPanel && dom.ocrPanel.style.display === 'none') {
      showOcrPanel(state.lastRawOcrText);
    } else {
      hideOcrPanel();
    }
  }

  function syncRawOcrButtonLabel() {
    if (!dom.btnShowRawOcr) return;
    const isOpen = dom.ocrPanel && dom.ocrPanel.style.display !== 'none';
    dom.btnShowRawOcr.textContent = isOpen ? 'Hide Raw OCR' : 'Raw OCR';
  }

  /* ────────────────────────────────────────────────────────────
     7. OCR INIT
     ──────────────────────────────────────────────────────────── */

  function initOcrModule() {
    initOcrSelection();

    if (dom.btnBlockCapture) {
      dom.btnBlockCapture.addEventListener('click', () => {
        if (state.blockCaptureMode) {
          deactivateBlockCapture();
        } else {
          activateBlockCapture();
        }
      });
    }

    if (dom.btnOcrPanelClose) {
      dom.btnOcrPanelClose.addEventListener('click', hideOcrPanel);
    }

    document.addEventListener('click', e => {
      const pickBtn = e.target.closest('.mc-pick-btn');
      if (pickBtn && pickBtn.dataset.pickTarget) {
        e.preventDefault();
        activatePickMode(pickBtn.dataset.pickTarget);
      }
    });

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (dom.eyeOverlay && dom.eyeOverlay.style.display !== 'none') {
          if (typeof root.closeEyePreview === 'function') root.closeEyePreview();
          return;
        }

        if (state.bubbleState === 'expanded') {
          if (typeof root.showBubbleMini === 'function') root.showBubbleMini();
          return;
        }

        if (state.pickTarget) {
          clearPickMode();
          return;
        }
      }
    });

    window.addEventListener('resize', () => {
      if (state.bubbleState === 'expanded') syncOcrCanvas();
    });
  }

  /* ────────────────────────────────────────────────────────────
     8. EXPORT TO SHARED ROOT
     ──────────────────────────────────────────────────────────── */

  root.initOCR = initOCR;
  root.syncOcrCanvas = syncOcrCanvas;
  root.initOcrSelection = initOcrSelection;
  root.performOCR = performOCR;
  root.fillNextField = fillNextField;

  root.activatePickMode = activatePickMode;
  root.clearPickMode = clearPickMode;

  root.activateBlockCapture = activateBlockCapture;
  root.activateBlockCaptureForGroup = activateBlockCaptureForGroup;
  root.deactivateBlockCapture = deactivateBlockCapture;

  root.parseGroupBlock = parseGroupBlock;
  root.fillGroupDraftFromOCR = fillGroupDraftFromOCR;

  root.showOcrPanel = showOcrPanel;
  root.hideOcrPanel = hideOcrPanel;
  root.toggleRawOcrPanel = toggleRawOcrPanel;
  root.syncRawOcrButtonLabel = syncRawOcrButtonLabel;

  root.initOcrModule = initOcrModule;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initOcrModule, { once: true });
  } else {
    initOcrModule();
  }
})();