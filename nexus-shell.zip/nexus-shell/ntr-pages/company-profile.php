<?php
/**
 * Company profile mockup for North Texas Remodel.
 */

$hub_slug = isset($hub_slug) ? $hub_slug : '';

$companies = [
    'blue-oak-builders' => [
        'name'        => 'Blue Oak Builders',
        'city'        => 'Frisco, Texas',
        'headline'    => 'Design-build kitchen remodeling with premium execution, transparent quoting, and homeowner-friendly communication.',
        'intro'       => 'This company profile page is structured to receive future KNX store rendering, Silva CRM lead capture, calculators, reviews, and blog content while already looking production-ready.',
        'services'    => [
            'Kitchen Remodeling',
            'Custom Cabinet Systems',
            'Countertop Upgrades',
            'Flooring Replacement',
            'Lighting Plans',
            'Finish Selections',
        ],
        'portfolio'   => [
            'Open-concept kitchen transformation',
            'Luxury cabinet and island rebuild',
            'Quartz + backsplash refresh',
            'Family-focused cooking layout redesign',
        ],
        'seo_blocks'  => [
            'Frisco kitchen remodel company',
            'North Texas custom cabinets',
            'premium countertop replacement',
        ],
        'reviews'     => [
            [
                'name' => 'Alyssa R.',
                'text' => 'The page feels ready for a real proposal experience. I can already imagine quote approvals and progress updates living here.',
            ],
            [
                'name' => 'Marcus T.',
                'text' => 'Clear service structure, clean presentation, and enough trust signals to move toward a consultation.',
            ],
            [
                'name' => 'Janelle P.',
                'text' => 'Exactly the kind of company detail page that makes a remodeling platform feel serious.',
            ],
        ],
        'articles'    => [
            'How to budget for a premium kitchen remodel in Frisco',
            'Cabinet replacement versus cabinet refacing',
            'What homeowners should prepare before a remodel starts',
        ],
    ],
    'lone-star-living' => [
        'name'        => 'Lone Star Living Co.',
        'city'        => 'Plano, Texas',
        'headline'    => 'Bathroom remodeling, shower systems, tile planning, and homeowner-first upgrade paths for modern North Texas homes.',
        'intro'       => 'This profile is designed as a scalable company shell that can later absorb live CRM and marketplace data without needing a visual rebuild.',
        'services'    => [
            'Bathroom Remodeling',
            'Walk-in Shower Systems',
            'Tile Installation',
            'Vanity Upgrades',
            'Waterproofing',
            'Accessibility Retrofits',
        ],
        'portfolio'   => [
            'Spa-style primary bathroom refresh',
            'Compact bathroom optimization',
            'Tile and vanity modernization',
            'Aging-in-place shower conversion',
        ],
        'seo_blocks'  => [
            'Plano bathroom remodel company',
            'tile and shower renovation',
            'accessible bathroom remodeling North Texas',
        ],
        'reviews'     => [
            [
                'name' => 'Chris M.',
                'text' => 'Very easy to understand what the company does and where the next actions will happen.',
            ],
            [
                'name' => 'Diana K.',
                'text' => 'The calculator and quote blocks feel like the right next step for this company page.',
            ],
            [
                'name' => 'Roger S.',
                'text' => 'This already feels more premium than most local remodeling sites.',
            ],
        ],
        'articles'    => [
            'Best bathroom materials for long-term maintenance',
            'How to plan a shower remodel without wasting budget',
            'The smartest bathroom upgrades for resale value',
        ],
    ],
    'north-peak-contracting' => [
        'name'        => 'North Peak Contracting',
        'city'        => 'McKinney, Texas',
        'headline'    => 'Whole-home renovations, additions, phased remodeling strategy, and operational project clarity built for scale.',
        'intro'       => 'This page demonstrates how a larger company profile can host service detail, portfolio storytelling, calculators, store previews, and CRM-ready conversion modules.',
        'services'    => [
            'Whole Home Renovation',
            'Room Additions',
            'Structural Coordination',
            'Project Planning',
            'Phased Remodel Execution',
            'Homeowner Update Workflows',
        ],
        'portfolio'   => [
            'Whole-home modernization plan',
            'Living space expansion',
            'Multi-phase renovation coordination',
            'High-visibility progress reporting demo',
        ],
        'seo_blocks'  => [
            'whole home renovation McKinney',
            'home addition contractor North Texas',
            'design-build remodeling company',
        ],
        'reviews'     => [
            [
                'name' => 'Heather J.',
                'text' => 'The structure makes it easy to imagine a real homeowner dashboard and progress flow later.',
            ],
            [
                'name' => 'Spencer D.',
                'text' => 'This feels like a platform page, not just a brochure page.',
            ],
            [
                'name' => 'Maya B.',
                'text' => 'The blog, calculator, and store placeholders make the ecosystem vision obvious.',
            ],
        ],
        'articles'    => [
            'How to phase a whole-home renovation without chaos',
            'What homeowners should know before planning an addition',
            'How remodeling companies can present scope with clarity',
        ],
    ],
];

$company = isset($companies[$hub_slug]) ? $companies[$hub_slug] : reset($companies);
?>

<section class="ntr-company-hero">
    <div class="ntr-container">
        <a class="ntr-back-link" href="<?php echo esc_url(home_url('/')); ?>">← Back to Explore</a>

        <div class="ntr-company-hero-shell">
            <div class="ntr-company-copy">
                <span class="ntr-eyebrow">Company Profile</span>
                <h1><?php echo esc_html($company['name']); ?></h1>
                <p class="ntr-company-location"><?php echo esc_html($company['city']); ?></p>
                <p class="ntr-company-headline"><?php echo esc_html($company['headline']); ?></p>

                <div class="ntr-hero-actions">
                    <a class="ntr-btn ntr-btn-primary" href="#calculator">Open Calculator</a>
                    <a class="ntr-btn ntr-btn-secondary" href="#knx-store">Open KNX Store</a>
                </div>
            </div>

            <div class="ntr-glass-card ntr-company-summary">
                <div class="ntr-summary-row">
                    <span>Prepared for</span>
                    <strong>Silva's CRM lead capture</strong>
                </div>
                <div class="ntr-summary-row">
                    <span>Prepared for</span>
                    <strong>KNX service/store surfaces</strong>
                </div>
                <div class="ntr-summary-row">
                    <span>Prepared for</span>
                    <strong>Reviews + blog + SEO scaling</strong>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ntr-company-nav-section">
    <div class="ntr-container">
        <div class="ntr-company-nav ntr-glass-card">
            <a href="#services">Services</a>
            <a href="#portfolio">Portfolio</a>
            <a href="#seo">SEO</a>
            <a href="#calculator">Calculator</a>
            <a href="#knx-store">KNX Store</a>
            <a href="#reviews">Reviews</a>
            <a href="#articles">Blog Articles</a>
        </div>
    </div>
</section>

<section class="ntr-company-intro-section">
    <div class="ntr-container">
        <div class="ntr-company-intro-grid">
            <div class="ntr-glass-card ntr-company-intro-card">
                <span class="ntr-eyebrow">Overview</span>
                <h2>A premium company page that can grow into a full remodeling ecosystem.</h2>
                <p><?php echo esc_html($company['intro']); ?></p>
            </div>

            <div class="ntr-glass-card ntr-company-kpis">
                <div class="ntr-kpi-box">
                    <strong>Services</strong>
                    <span><?php echo esc_html(count($company['services'])); ?> listed</span>
                </div>
                <div class="ntr-kpi-box">
                    <strong>Portfolio</strong>
                    <span><?php echo esc_html(count($company['portfolio'])); ?> showcase items</span>
                </div>
                <div class="ntr-kpi-box">
                    <strong>Content</strong>
                    <span><?php echo esc_html(count($company['articles'])); ?> article slots</span>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="services">
    <div class="ntr-container">
        <div class="ntr-section-head">
            <div>
                <span class="ntr-eyebrow">Services</span>
                <h2>Service grid prepared for future hub-level rendering.</h2>
            </div>
            <p>These cards are intentionally structured to be replaced later by dynamic KNX or CRM-fed service data.</p>
        </div>

        <div class="ntr-service-grid">
            <?php foreach ($company['services'] as $service) : ?>
                <article class="ntr-glass-card ntr-service-card">
                    <span class="ntr-service-icon"></span>
                    <h3><?php echo esc_html($service); ?></h3>
                    <p>Prepared for service descriptions, pricing cues, eligibility logic, and conversion CTAs.</p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="portfolio">
    <div class="ntr-container">
        <div class="ntr-section-head">
            <div>
                <span class="ntr-eyebrow">Portfolio</span>
                <h2>Portfolio mockups with gallery-ready surfaces.</h2>
            </div>
            <p>These blocks are designed to receive project photos, milestones, and finished result storytelling.</p>
        </div>

        <div class="ntr-portfolio-grid">
            <?php foreach ($company['portfolio'] as $item) : ?>
                <article class="ntr-glass-card ntr-portfolio-card">
                    <div class="ntr-portfolio-visual"></div>
                    <h3><?php echo esc_html($item); ?></h3>
                    <p>Placeholder surface for project snapshots, scope summaries, and before/after storytelling.</p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="seo">
    <div class="ntr-container">
        <div class="ntr-company-two-col">
            <div class="ntr-glass-card ntr-seo-card">
                <span class="ntr-eyebrow">SEO</span>
                <h2>Location and service-driven content surfaces.</h2>
                <p>
                    This space is intentionally built for local relevance, service explanations, trust copy, and semantic
                    support content that can later help ranking and conversion at the same time.
                </p>

                <div class="ntr-tag-row">
                    <?php foreach ($company['seo_blocks'] as $seo) : ?>
                        <span class="ntr-chip ntr-chip-soft"><?php echo esc_html($seo); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="ntr-glass-card ntr-crm-cta-card">
                <span class="ntr-eyebrow">Silva's CRM</span>
                <h2>Lead capture and estimate handoff zone.</h2>
                <p>Prepared for consultation requests, guided quote intake, approval flows, and customer portal entry.</p>
                <div class="ntr-card-actions">
                    <a class="ntr-btn ntr-btn-primary" href="#calculator">Request Quote</a>
                    <a class="ntr-btn ntr-btn-secondary" href="#articles">Read Articles</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="calculator">
    <div class="ntr-container">
        <div class="ntr-glass-card ntr-module-shell">
            <div class="ntr-module-head">
                <div>
                    <span class="ntr-eyebrow">Calculator</span>
                    <h2>Calculator module shell prepared for future integration.</h2>
                </div>
                <span class="ntr-chip">KNX-ready</span>
            </div>

            <div class="ntr-module-grid">
                <div class="ntr-module-card">
                    <strong>Project Type</strong>
                    <p>Kitchen, bathroom, whole-home, additions, finishes.</p>
                </div>
                <div class="ntr-module-card">
                    <strong>Scope Inputs</strong>
                    <p>Measurements, materials, complexity, labor categories.</p>
                </div>
                <div class="ntr-module-card">
                    <strong>Estimate Preview</strong>
                    <p>Prepared to feed CRM, proposal generation, or next-step consultation.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="knx-store">
    <div class="ntr-container">
        <div class="ntr-glass-card ntr-module-shell">
            <div class="ntr-module-head">
                <div>
                    <span class="ntr-eyebrow">KNX Store</span>
                    <h2>Store preview surface for materials, packages, and upsells.</h2>
                </div>
                <span class="ntr-chip">Store-ready</span>
            </div>

            <div class="ntr-store-grid">
                <article class="ntr-store-card">
                    <h3>Cabinet Package</h3>
                    <p>Prepared for SKU logic, pricing, variants, and labor connection.</p>
                </article>
                <article class="ntr-store-card">
                    <h3>Countertop Upgrade</h3>
                    <p>Prepared for material selection, lead times, and store add-ons.</p>
                </article>
                <article class="ntr-store-card">
                    <h3>Tile Collection</h3>
                    <p>Prepared for supplier presentation and project package building.</p>
                </article>
            </div>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="reviews">
    <div class="ntr-container">
        <div class="ntr-section-head">
            <div>
                <span class="ntr-eyebrow">Reviews</span>
                <h2>Trust surfaces for conversion and credibility.</h2>
            </div>
            <p>These review cards can later be replaced with dynamic review rendering without changing the layout system.</p>
        </div>

        <div class="ntr-review-grid">
            <?php foreach ($company['reviews'] as $review) : ?>
                <article class="ntr-glass-card ntr-review-card">
                    <div class="ntr-rating-row">
                        <span class="ntr-rating-pill">5.0 ★</span>
                    </div>
                    <p><?php echo esc_html($review['text']); ?></p>
                    <strong><?php echo esc_html($review['name']); ?></strong>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ntr-company-section" id="articles">
    <div class="ntr-container">
        <div class="ntr-section-head">
            <div>
                <span class="ntr-eyebrow">Blog Articles</span>
                <h2>SEO-ready article cards connected to the company journey.</h2>
            </div>
            <p>These article surfaces are placed here intentionally to reinforce trust, answer objections, and support local SEO.</p>
        </div>

        <div class="ntr-article-grid">
            <?php foreach ($company['articles'] as $article) : ?>
                <article class="ntr-glass-card ntr-article-card">
                    <span class="ntr-chip ntr-chip-soft">Blog</span>
                    <h3><?php echo esc_html($article); ?></h3>
                    <p>Prepared for excerpt, publish date, local relevance, and CTA routing toward estimate or consultation.</p>
                    <a class="ntr-inline-link" href="<?php echo esc_url(home_url('/')); ?>">Read article</a>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>