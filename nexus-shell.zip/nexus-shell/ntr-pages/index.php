<?php
/**
 * Main theme entry for North Texas Remodel mock frontend.
 */

get_header();

$template_dir = trailingslashit(get_template_directory()) . 'ntr-pages/';
$hub_slug     = isset($_GET['hub']) ? sanitize_title(wp_unslash($_GET['hub'])) : '';

echo '<main class="ntr-app-shell">';

if (! empty($hub_slug) && file_exists($template_dir . 'company-profile.php')) {
    include $template_dir . 'company-profile.php';
} elseif (file_exists($template_dir . 'explore-home.php')) {
    include $template_dir . 'explore-home.php';
} else {
    echo '<section class="ntr-fallback">';
    echo '<div class="ntr-container">';
    echo '<div class="ntr-glass-card ntr-empty-state">';
    echo '<h1>North Texas Remodel</h1>';
    echo '<p>The frontend template files were not found. Please create the files inside <strong>/ntr-pages/</strong>.</p>';
    echo '</div>';
    echo '</div>';
    echo '</section>';
}

echo '</main>';

get_footer();