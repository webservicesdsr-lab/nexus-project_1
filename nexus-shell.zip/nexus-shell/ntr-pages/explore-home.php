<?php
/**
 * Explore landing mockup for North Texas Remodel.
 */

$hubs = [
    [
        'slug'        => 'blue-oak-builders',
        'name'        => 'Blue Oak Builders',
        'city'        => 'Frisco',
        'project'     => 'Kitchen Remodeling',
        'rating'      => '4.9',
        'reviews'     => '128',
        'description' => 'Luxury kitchen transformations, cabinet refacing, premium surfaces, and design-build execution for modern family homes.',
        'tags'        => ['Design-Build', 'Premium Kitchens', 'Fast Proposals'],
        'services'    => ['Kitchen Remodels', 'Cabinets', 'Countertops'],
    ],
    [
        'slug'        => 'lone-star-living',
        'name'        => 'Lone Star Living Co.',
        'city'        => 'Plano',
        'project'     => 'Bathroom Remodeling',
        'rating'      => '4.8',
        'reviews'     => '96',
        'description' => 'Clean bathroom upgrades, tile systems, shower conversions, and accessible layout planning backed by transparent quote workflows.',
        'tags'        => ['Bathrooms', 'Tile Systems', 'Accessibility'],
        'services'    => ['Bathroom Remodels', 'Tile', 'Shower Systems'],
    ],
    [
        'slug'        => 'north-peak-contracting',
        'name'        => 'North Peak Contracting',
        'city'        => 'McKinney',
        'project'     => 'Whole Home Renovation',
        'rating'      => '5.0',
        'reviews'     => '74',
        'description' => 'Whole-home planning, structural coordination, phased execution, and homeowner updates prepared for Silva CRM and KNX workflows.',
        'tags'        => ['Whole Home', 'Project Tracking', 'Materials Planning'],
        'services'    => ['Whole Home Remodels', 'Additions', 'Project Management'],
    ],
];

$city_filters    = ['All Cities', 'Frisco', 'Plano', 'McKinney', 'Dallas', 'Prosper'];
$project_filters = ['All Projects', 'Kitchen Remodeling', 'Bathroom Remodeling', 'Whole Home Renovation', 'Additions', 'Exterior'];
?>

<section class="ntr-hero-section">
    <div class="ntr-container">
        <div class="ntr-hero-grid">
            <div class="ntr-hero-copy">
                <span class="ntr-eyebrow">North Texas Remodel Ecosystem</span>
                <h1>Explore contractors, compare remodeling paths, and prepare every project for Silva CRM + KNX.</h1>
                <p>
                    This landing page is designed as the production-ready frontend shell for a remodeling marketplace.
                    Homeowners can discover trusted companies, compare project types, move into calculators, and later
                    connect with quotes, CRM flows, reviews, blogs, and KNX-powered store experiences.
                </p>

                <div class="ntr-hero-actions">
                    <a class="ntr-btn ntr-btn-primary" href="#explore-grid">Explore Companies</a>
                    <a class="ntr-btn ntr-btn-secondary" href="#platform-readiness">See Platform Readiness</a>
                </div>

                <div class="ntr-hero-metrics">
                    <div class="ntr-metric-card">
                        <strong>24h</strong>
                        <span>Quote response target</span>
                    </div>
                    <div class="ntr-metric-card">
                        <strong>3 Layers</strong>
                        <span>Explore, compare, convert</span>
                    </div>
                    <div class="ntr-metric-card">
                        <strong>CRM + KNX</strong>
                        <span>Mock surfaces ready</span>
                    </div>
                </div>
            </div>

            <div class="ntr-hero-panel ntr-glass-card">
                <div class="ntr-panel-header">
                    <span class="ntr-chip">Live UX Mockup</span>
                    <span class="ntr-chip ntr-chip-soft">Landing v1</span>
                </div>

                <div class="ntr-hero-stack">
                    <div class="ntr-stack-card">
                        <div>
                            <small>Discover</small>
                            <h3>City + project type filters</h3>
                        </div>
                        <span>01</span>
                    </div>

                    <div class="ntr-stack-card">
                        <div>
                            <small>Compare</small>
                            <h3>Companies, services, reviews, portfolio</h3>
                        </div>
                        <span>02</span>
                    </div>

                    <div class="ntr-stack-card">
                        <div>
                            <small>Convert</small>
                            <h3>Calculator, store, CRM-ready quote journey</h3>
                        </div>
                        <span>03</span>
                    </div>
                </div>

                <div class="ntr-hero-surface">
                    <div class="ntr-mini-stat">
                        <span>Prepared for</span>
                        <strong>Silva's CRM intake</strong>
                    </div>
                    <div class="ntr-mini-stat">
                        <span>Prepared for</span>
                        <strong>KNX company / hub rendering</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ntr-filter-section" id="explore-grid">
    <div class="ntr-container">
        <div class="ntr-section-head">
            <div>
                <span class="ntr-eyebrow">Explore</span>
                <h2>Find the right remodeling company for your city and project type.</h2>
            </div>
            <p>
                This section is intentionally designed as the first touchpoint for future dynamic hub rendering.
                For now it behaves like a premium mockup with a clean UX foundation.
            </p>
        </div>

        <div class="ntr-glass-card ntr-filter-bar">
            <div class="ntr-filter-group">
                <label for="ntr-city-filter">City</label>
                <select id="ntr-city-filter">
                    <?php foreach ($city_filters as $city) : ?>
                        <option><?php echo esc_html($city); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ntr-filter-group">
                <label for="ntr-project-filter">Project Type</label>
                <select id="ntr-project-filter">
                    <?php foreach ($project_filters as $project) : ?>
                        <option><?php echo esc_html($project); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ntr-filter-group">
                <label for="ntr-search-filter">Search</label>
                <input id="ntr-search-filter" type="text" placeholder="Company, service, or style..." />
            </div>

            <div class="ntr-filter-actions">
                <button class="ntr-btn ntr-btn-primary" type="button">Apply Filters</button>
                <button class="ntr-btn ntr-btn-ghost" type="button">Reset</button>
            </div>
        </div>

        <div class="ntr-hub-grid">
            <?php foreach ($hubs as $hub) : ?>
                <article class="ntr-hub-card ntr-glass-card">
                    <div class="ntr-hub-media">
                        <span class="ntr-hub-badge"><?php echo esc_html($hub['city']); ?></span>
                        <div class="ntr-hub-orb"></div>
                    </div>

                    <div class="ntr-hub-content">
                        <div class="ntr-rating-row">
                            <span class="ntr-rating-pill"><?php echo esc_html($hub['rating']); ?> ★</span>
                            <span><?php echo esc_html($hub['reviews']); ?> reviews</span>
                        </div>

                        <h3><?php echo esc_html($hub['name']); ?></h3>
                        <p class="ntr-project-label"><?php echo esc_html($hub['project']); ?></p>
                        <p><?php echo esc_html($hub['description']); ?></p>

                        <div class="ntr-tag-row">
                            <?php foreach ($hub['tags'] as $tag) : ?>
                                <span class="ntr-chip ntr-chip-soft"><?php echo esc_html($tag); ?></span>
                            <?php endforeach; ?>
                        </div>

                        <ul class="ntr-inline-list">
                            <?php foreach ($hub['services'] as $service) : ?>
                                <li><?php echo esc_html($service); ?></li>
                            <?php endforeach; ?>
                        </ul>

                        <div class="ntr-card-actions">
                            <a class="ntr-btn ntr-btn-primary" href="<?php echo esc_url(add_query_arg('hub', $hub['slug'], home_url('/'))); ?>">
                                View Company
                            </a>
                            <a class="ntr-btn ntr-btn-secondary" href="#platform-readiness">CRM Flow</a>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ntr-showcase-section">
    <div class="ntr-container">
        <div class="ntr-section-head">
            <div>
                <span class="ntr-eyebrow">Landing Architecture</span>
                <h2>A polished frontend designed to receive real modules later.</h2>
            </div>
            <p>
                The layout below is intentionally structured so Silva's CRM and KNX can plug into a shell that already
                feels premium, organized, and trustworthy.
            </p>
        </div>

        <div class="ntr-showcase-grid">
            <div class="ntr-glass-card ntr-feature-panel">
                <h3>Silva's CRM Readiness</h3>
                <ul>
                    <li>Lead capture zones</li>
                    <li>Quote request entry points</li>
                    <li>Estimate approval callouts</li>
                    <li>Customer pipeline support surfaces</li>
                </ul>
            </div>

            <div class="ntr-glass-card ntr-feature-panel">
                <h3>KNX Readiness</h3>
                <ul>
                    <li>Company / hub rendering grid</li>
                    <li>Future calculator handoff</li>
                    <li>Store section placement</li>
                    <li>Marketplace navigation logic</li>
                </ul>
            </div>

            <div class="ntr-glass-card ntr-feature-panel">
                <h3>SEO + Content Readiness</h3>
                <ul>
                    <li>Service-driven landing copy blocks</li>
                    <li>Blog preview sections</li>
                    <li>Location relevance surfaces</li>
                    <li>Review and trust-building sections</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="ntr-platform-section" id="platform-readiness">
    <div class="ntr-container">
        <div class="ntr-platform-shell ntr-glass-card">
            <div class="ntr-platform-copy">
                <span class="ntr-eyebrow">System Map</span>
                <h2>The landing page is already organized for the future platform stack.</h2>
                <p>
                    Instead of designing a pretty shell with no future, this homepage is deliberately arranged to host
                    discovery, conversion, and operational depth across contractors, homeowners, estimates, project updates,
                    store modules, calculators, and long-form SEO content.
                </p>
            </div>

            <div class="ntr-platform-grid">
                <div class="ntr-platform-card">
                    <small>01</small>
                    <h3>Explore</h3>
                    <p>Visitors discover companies by city and project type.</p>
                </div>
                <div class="ntr-platform-card">
                    <small>02</small>
                    <h3>Company Profile</h3>
                    <p>Each hub gets a complete marketing and conversion surface.</p>
                </div>
                <div class="ntr-platform-card">
                    <small>03</small>
                    <h3>Calculator + Store</h3>
                    <p>Prepared spaces for KNX calculator and store surfaces.</p>
                </div>
                <div class="ntr-platform-card">
                    <small>04</small>
                    <h3>CRM Handoff</h3>
                    <p>Lead and estimate flows can connect into Silva's CRM later.</p>
                </div>
            </div>
        </div>
    </div>
</section>